﻿create table tb_conjuntos(

id_conj INTEGER NOT NULL PRIMARY KEY IDENTITY(1,1),
cod_conj varchar(20) NOT NULL, 
nome_conj varchar(50) NOT NULL,




);