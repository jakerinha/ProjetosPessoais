﻿create table tb_conjuntos_componentes(
id_comp INTEGER NOT NULL, 
nome_conj varchar(50) NOT NULL
CONSTRAINT fk_conj_comp foreign key (id_comp)
references tb_componentes (id_comp)
);