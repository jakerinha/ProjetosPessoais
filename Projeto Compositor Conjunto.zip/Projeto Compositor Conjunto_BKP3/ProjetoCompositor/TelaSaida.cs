﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjetoCompositor
{
    public partial class TelaSaida : Form
    {
        //Essa variável(quantidade) receberá o valor atual da quantidade de componentes disponíveis!
        int quantidade_atual;
        
        public TelaSaida()
        {
            InitializeComponent();
        }
        //Código utilizado para buscar o componente através do nome.
        private void BuscarComponenteNome()
        {
            try
            {
                if (String.IsNullOrEmpty(txtBoxDescricaoComp.Text) != false)
                {
                    MessageBox.Show("Campo Descrição não pode ser vázio!", "ATENÇÃO");
                    ClassUtilidades.DataReader.Close();
                }
                else
                {
                    ClassConexao.Aberto();

                    ClassUtilidades._nomeComp = txtBoxDescricaoComp.Text;
                    ClassUtilidades._TelaComponente = 0;

                    TelaBuscaComponente buscaComponente = new TelaBuscaComponente();
                    
                    buscaComponente.ShowDialog();

                    txtBoxDescricaoComp.Text = ClassUtilidades._nomeComp;
                    txtBoxCodComp.Text = ClassUtilidades._codComp;

                    BuscaComponenteCod();

                    ClassConexao.Fechar();
                }
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }
        private void InserirMovimentacao()
        {
            try
            {
                ClassConexao.Aberto();

                string inserir_movimentacao = "INSERT INTO tb_movimentacao (cod_material, descricao_mov, qtd_mov, status_mov, data_emissao_nota, data_saida, usuario_mov) values (@cod_material, @descricao_mov, @qtd_mov, @status_mov, @data_emissao_nota,@data_saida, @usuario_mov)";

                SqlCommand insert_moviment = new SqlCommand(inserir_movimentacao, ClassConexao.connection);

                insert_moviment.Parameters.AddWithValue("@cod_material", txtBoxCodComp.Text);
                insert_moviment.Parameters.AddWithValue("@descricao_mov", txtBoxDescricaoComp.Text);
                insert_moviment.Parameters.AddWithValue("@qtd_mov", Convert.ToInt32(txtBoxQtdComp.Text));
                insert_moviment.Parameters.AddWithValue("status_mov", "S");
                insert_moviment.Parameters.AddWithValue("@data_emissao_nota", "--------");
                insert_moviment.Parameters.AddWithValue("@data_saida", txtBoxDataAjuste.Text);
                insert_moviment.Parameters.AddWithValue("@usuario_mov", ClassUtilidades._usuario);

                if(insert_moviment.ExecuteNonQuery() != -1)
                {

                    MessageBox.Show("SUCESSO!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Ocorreu algum erro na geração de saída!", "ATENÇÃO");
                }

                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }
        //Código para atualização do estoque dos componentes
        private void AtualizaEstoqueComponente()
        {
            try
            {
                ClassConexao.Aberto();

                string atualiza_estoque = "UPDATE tb_componentes SET qtd_comp = @qtd_comp WHERE cod_comp = @cod_comp";

                SqlCommand update_store = new SqlCommand(atualiza_estoque, ClassConexao.connection);

                update_store.Parameters.AddWithValue("@qtd_comp", Convert.ToInt32(lblFutura.Text));
                update_store.Parameters.AddWithValue("@cod_comp", txtBoxCodComp.Text);

                if(update_store.ExecuteNonQuery() != -1)
                {
                    //Adicionar inserção na tabela de movimentação!
                    InserirMovimentacao();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Ocorreu um erro ao atualizar o estoque!", "ATENÇÃO");
                }


                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }
        //Código para verificar a operação a ser efetuada. Se é uma adição em relação ao estoque ou uma redução.

        private void OperacaoAdicaoSubtracao()
        {
            //Variável local criada para evitar incoerências nos valores.
            int qtde_atual = quantidade_atual;
            //Conversão do campo relacionado a quantidade que posteriormente o componente receberá.
            int qtde = Convert.ToInt32(txtBoxQtdComp.Text);
            
            if (String.IsNullOrEmpty(txtBoxQtdComp.Text) != false)
            {
                MessageBox.Show("O campo Quantidade Componentes não pode ser vázio!", "ATENÇÃO");
            }
            else
            {
                //Verifica se a operação de adição está selecionada
                if (rbAdicao.Checked == true)
                {
                    qtde_atual += qtde;
                    lblFutura.Text = qtde_atual.ToString();
                }
                else if(rbSubtracao.Checked == true)
                {
                    qtde_atual -= qtde;
                    lblFutura.Text = qtde_atual.ToString();
                }
                else
                {
                    MessageBox.Show("Selecione uma das opções!", "ATENÇÃO");
                    rbAdicao.Focus();
                }
            }
        }

        //Código para chamada de Componentes visados pelo usuário
        private void BuscaComponenteCod()
        {
            try
            {
                if(String.IsNullOrEmpty(txtBoxCodComp.Text) != false)
                {
                    MessageBox.Show("O campo Código Componente não pode ser vázio!", "ATENÇÃO");
                }
                else
                {
                    ClassConexao.Aberto();

                    string seleciona_comp_cod = "SELECT top 1 nome_comp, qtd_comp FROM tb_componentes WHERE cod_comp like @cod_comp";

                    SqlCommand select_cod = new SqlCommand(seleciona_comp_cod, ClassConexao.connection);

                    select_cod.Parameters.AddWithValue("@cod_comp", txtBoxCodComp.Text);

                    ClassUtilidades.DataReader = select_cod.ExecuteReader();

                    if (ClassUtilidades.DataReader.Read() != false)
                    {
                        //Atribui ao campo da descrição do componente a sua dévida descrição!
                        txtBoxDescricaoComp.Text = ClassUtilidades.DataReader.GetString(0);
                        //Recebe a quantidade atual do componente visado!
                        quantidade_atual = ClassUtilidades.DataReader.GetInt32(1);
                        //Apresenta a sua quantidade em um label para melhor compreensão do usuário
                        lblAtual.Text = quantidade_atual.ToString();
                        ClassUtilidades.DataReader.Close();
                    }
                    else
                    {
                        MessageBox.Show("Leitura do valor informado sem sucesso!", "ATENÇÃO");
                        ClassUtilidades.DataReader.Close();
                    }

                    ClassConexao.Fechar();
                }
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void txtBoxQtdComp_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                OperacaoAdicaoSubtracao();
                
            }
        }

        private void TelaSaida_Load(object sender, EventArgs e)
        {
            //Recebe a data do dia que houve o ajuste e o horário
            txtBoxDataAjuste.Text = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
            //Recebe o nome do usuário operante no sistema
            txtBoxAtorAjuste.Text = ClassUtilidades._usuario;
        }

        private void txtBoxCodComp_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                //Chama o método para buscar dados relacionados ao código fornecido de determinado
                //componente.
                BuscaComponenteCod();
                txtBoxCodComp.Enabled = false;
                txtBoxDescricaoComp.Enabled = false;
            }
        }

        private void txtBoxQtdComp_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Tratamento de campo para somente receber números!
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)8)
            {
                //Handled diz se o que está sendo pressionado são caracteres alfabéticos
                e.Handled = true;
            }
        }

        private void btnAjustar_Click(object sender, EventArgs e)
        {
            AtualizaEstoqueComponente();
        }

        private void txtBoxDescricaoComp_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                BuscarComponenteNome();
                txtBoxDescricaoComp.Text = ClassUtilidades._nomeComp;
                txtBoxCodComp.Enabled = false;
                txtBoxDescricaoComp.Enabled = false;
            }
        }
    }
}
