﻿namespace ProjetoCompositor
{
    partial class TelaPesquisaConjunto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.txtCodConjunto = new System.Windows.Forms.TextBox();
            this.txtDescricaoConjunto = new System.Windows.Forms.TextBox();
            this.cbModelo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvConjuntos = new System.Windows.Forms.DataGridView();
            this.tbconjuntosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bDCompositor_tb_conjuntos = new ProjetoCompositor.BDCompositor_tb_conjuntos();
            this.tb_conjuntosTableAdapter = new ProjetoCompositor.BDCompositor_tb_conjuntosTableAdapters.tb_conjuntosTableAdapter();
            this.idconjDGVtxtbox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codconjDGVtxtbox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeconjDGVtxtbox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modeloconjDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConjuntos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbconjuntosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDCompositor_tb_conjuntos)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.btnLimpar);
            this.groupBox1.Controls.Add(this.btnConsultar);
            this.groupBox1.Controls.Add(this.txtCodConjunto);
            this.groupBox1.Controls.Add(this.txtDescricaoConjunto);
            this.groupBox1.Controls.Add(this.cbModelo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(553, 119);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filtro de Conjuntos";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLimpar.Location = new System.Drawing.Point(472, 39);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnConsultar
            // 
            this.btnConsultar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnConsultar.Location = new System.Drawing.Point(472, 12);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(75, 23);
            this.btnConsultar.TabIndex = 6;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // 
            // txtCodConjunto
            // 
            this.txtCodConjunto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCodConjunto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCodConjunto.Location = new System.Drawing.Point(14, 39);
            this.txtCodConjunto.Name = "txtCodConjunto";
            this.txtCodConjunto.Size = new System.Drawing.Size(104, 20);
            this.txtCodConjunto.TabIndex = 5;
            // 
            // txtDescricaoConjunto
            // 
            this.txtDescricaoConjunto.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDescricaoConjunto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescricaoConjunto.Location = new System.Drawing.Point(14, 79);
            this.txtDescricaoConjunto.Name = "txtDescricaoConjunto";
            this.txtDescricaoConjunto.Size = new System.Drawing.Size(443, 20);
            this.txtDescricaoConjunto.TabIndex = 4;
            // 
            // cbModelo
            // 
            this.cbModelo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbModelo.FormattingEnabled = true;
            this.cbModelo.Location = new System.Drawing.Point(124, 38);
            this.cbModelo.Name = "cbModelo";
            this.cbModelo.Size = new System.Drawing.Size(152, 21);
            this.cbModelo.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(121, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Modelo";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Descrição Conjunto";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cód. Conjunto";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvConjuntos);
            this.groupBox2.Location = new System.Drawing.Point(12, 137);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(553, 233);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Conjuntos";
            // 
            // dgvConjuntos
            // 
            this.dgvConjuntos.AllowUserToAddRows = false;
            this.dgvConjuntos.AllowUserToDeleteRows = false;
            this.dgvConjuntos.AutoGenerateColumns = false;
            this.dgvConjuntos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConjuntos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idconjDGVtxtbox,
            this.codconjDGVtxtbox,
            this.nomeconjDGVtxtbox,
            this.modeloconjDataGridViewTextBoxColumn});
            this.dgvConjuntos.DataSource = this.tbconjuntosBindingSource;
            this.dgvConjuntos.Location = new System.Drawing.Point(6, 19);
            this.dgvConjuntos.Name = "dgvConjuntos";
            this.dgvConjuntos.ReadOnly = true;
            this.dgvConjuntos.Size = new System.Drawing.Size(541, 208);
            this.dgvConjuntos.TabIndex = 0;
            this.dgvConjuntos.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvConjuntos_CellDoubleClick);
            // 
            // tbconjuntosBindingSource
            // 
            this.tbconjuntosBindingSource.DataMember = "tb_conjuntos";
            this.tbconjuntosBindingSource.DataSource = this.bDCompositor_tb_conjuntos;
            // 
            // bDCompositor_tb_conjuntos
            // 
            this.bDCompositor_tb_conjuntos.DataSetName = "BDCompositor_tb_conjuntos";
            this.bDCompositor_tb_conjuntos.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_conjuntosTableAdapter
            // 
            this.tb_conjuntosTableAdapter.ClearBeforeFill = true;
            // 
            // idconjDGVtxtbox
            // 
            this.idconjDGVtxtbox.DataPropertyName = "id_conj";
            this.idconjDGVtxtbox.HeaderText = "ID";
            this.idconjDGVtxtbox.Name = "idconjDGVtxtbox";
            this.idconjDGVtxtbox.ReadOnly = true;
            this.idconjDGVtxtbox.Width = 50;
            // 
            // codconjDGVtxtbox
            // 
            this.codconjDGVtxtbox.DataPropertyName = "cod_conj";
            this.codconjDGVtxtbox.HeaderText = "Cód. Conjunto";
            this.codconjDGVtxtbox.Name = "codconjDGVtxtbox";
            this.codconjDGVtxtbox.ReadOnly = true;
            this.codconjDGVtxtbox.Width = 150;
            // 
            // nomeconjDGVtxtbox
            // 
            this.nomeconjDGVtxtbox.DataPropertyName = "nome_conj";
            this.nomeconjDGVtxtbox.HeaderText = "Descrição Conjunto";
            this.nomeconjDGVtxtbox.Name = "nomeconjDGVtxtbox";
            this.nomeconjDGVtxtbox.ReadOnly = true;
            this.nomeconjDGVtxtbox.Width = 200;
            // 
            // modeloconjDataGridViewTextBoxColumn
            // 
            this.modeloconjDataGridViewTextBoxColumn.DataPropertyName = "modelo_conj";
            this.modeloconjDataGridViewTextBoxColumn.HeaderText = "Modelo";
            this.modeloconjDataGridViewTextBoxColumn.Name = "modeloconjDataGridViewTextBoxColumn";
            this.modeloconjDataGridViewTextBoxColumn.ReadOnly = true;
            this.modeloconjDataGridViewTextBoxColumn.Width = 150;
            // 
            // TelaPesquisaConjunto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(577, 382);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "TelaPesquisaConjunto";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Consultar Conjuntos";
            this.Load += new System.EventHandler(this.TelaPesquisaConjunto_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvConjuntos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbconjuntosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDCompositor_tb_conjuntos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.TextBox txtCodConjunto;
        private System.Windows.Forms.TextBox txtDescricaoConjunto;
        private System.Windows.Forms.ComboBox cbModelo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvConjuntos;
        private System.Windows.Forms.Button btnLimpar;
        private BDCompositor_tb_conjuntos bDCompositor_tb_conjuntos;
        private System.Windows.Forms.BindingSource tbconjuntosBindingSource;
        private BDCompositor_tb_conjuntosTableAdapters.tb_conjuntosTableAdapter tb_conjuntosTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idconjDGVtxtbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn codconjDGVtxtbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeconjDGVtxtbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn modeloconjDataGridViewTextBoxColumn;
    }
}