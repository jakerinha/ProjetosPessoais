﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjetoCompositor
{
    public partial class TelaCadastroComponente : Form
    {
        int id;
        public TelaCadastroComponente()
        {
            InitializeComponent();

            txtDescricao.Focus();

            try
            {
                
                ClassConexao.Aberto();

                string selecionar = "SELECT top 1 id_comp from tb_componentes order by id_comp desc";

                SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                id = Convert.ToInt32(select.ExecuteScalar()) + 1;

                txtID.Text = id.ToString();

                ClassConexao.Fechar();
                
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }

        }

        private void BtnCadastrarComponente_Click(object sender, EventArgs e)
        {
            try
            {
                ClassConexao.Aberto();

                string inserir = "INSERT INTO tb_componentes(cod_comp, nome_comp) values (@cod_comp, @nome_comp)";

                SqlCommand insert = new SqlCommand(inserir, ClassConexao.connection);
                //Parametrizando os campos da tabela componentes cod_comp e nome_comp
                insert.Parameters.AddWithValue("@cod_comp", txtCodBarra.Text);
                insert.Parameters.AddWithValue("@nome_comp", txtDescricao.Text);

                if (insert.ExecuteNonQuery() != -1)
                {
                    MessageBox.Show("COMPONENTE CADASTRADO COM SUCESSO!", "ATENÇÃO!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    id++;
                    txtID.Text = id.ToString();
                    txtCodBarra.Clear();
                    txtDescricao.Clear();
                }
                else
                {
                    MessageBox.Show("OCORREU UM ERRO COM O CADASTRO!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void TelaCadastroComponente_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("VOCÊ TEM CERTEZA QUE DESEJA SAIR?", "ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtDescricao.Clear();
            txtCodBarra.Clear();
            
        }
    }
}
