﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjetoCompositor
{
    public partial class TelaPesquisaConjunto : Form
    {
        DataSet ds = new DataSet();
        
        public TelaPesquisaConjunto()
        {
            InitializeComponent();
            BuscarModelos();

        }

        private void TelaPesquisaConjunto_Load(object sender, EventArgs e)
        {
            
            // TODO: esta linha de código carrega dados na tabela 'bDCompositor_tb_conjuntos.tb_conjuntos'. Você pode movê-la ou removê-la conforme necessário.
            //this.tb_conjuntosTableAdapter.Fill(this.bDCompositor_tb_conjuntos.tb_conjuntos);

            txtDescricaoConjunto.Text = ClassUtilidades._descricao_conjunto;
            ClassUtilidades._descricao_conjunto = "";
            //BuscarConjuntos();
            

        }
        private void BuscarModelos()
        {
            try
            {
                ClassConexao.Aberto();
                string seleciona_modelos = "SELECT * FROM tb_modelos";
                int i;
                SqlCommand select_model = new SqlCommand(seleciona_modelos, ClassConexao.connection);

                ClassUtilidades.DataReader = select_model.ExecuteReader();

                for(i = 0; ClassUtilidades.DataReader.Read() == true; i++)
                {
                    cbModelo.Items.Insert(i, ClassUtilidades.DataReader.GetString(0));
                }

                ClassUtilidades.DataReader.Close();
                //dataReader.Dispose();
                
                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void BuscarConjuntos()
        {
            try
            {
                ClassConexao.Aberto();
                if (String.IsNullOrEmpty(txtDescricaoConjunto.Text) != false && String.IsNullOrEmpty(txtCodConjunto.Text) != false && String.IsNullOrEmpty(cbModelo.Text) != false)
                {
                    ds.Clear();
                    string seleciona_tudo = "SELECT * FROM tb_conjuntos";

                    SqlCommand select_all = new SqlCommand(seleciona_tudo, ClassConexao.connection);

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(select_all);

                    dataAdapter.Fill(ds);

                    dgvConjuntos.DataSource = ds;
                    dgvConjuntos.DataMember = ds.Tables[0].TableName;

                }
                else if(String.IsNullOrEmpty(txtDescricaoConjunto.Text) == false)
                {

                    ds.Clear();
                    string seleciona_p_nome = "SELECT * FROM tb_conjuntos WHERE nome_conj like '%" + txtDescricaoConjunto.Text + "%'";

                    SqlCommand select_name = new SqlCommand(seleciona_p_nome, ClassConexao.connection);

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(select_name);

                    dataAdapter.Fill(ds);

                    dgvConjuntos.DataSource = ds;
                    dgvConjuntos.DataMember = ds.Tables[0].TableName;

                }
                else if (String.IsNullOrEmpty(txtCodConjunto.Text) == false)
                {

                    ds.Clear();

                    string seleciona_p_id = "SELECT * FROM tb_conjuntos WHERE cod_conj = @cod_conj";

                    SqlCommand select_id = new SqlCommand(seleciona_p_id, ClassConexao.connection);

                    select_id.Parameters.AddWithValue("@cod_conj", txtCodConjunto.Text);

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(select_id);

                    dataAdapter.Fill(ds);

                    dgvConjuntos.DataSource = ds;

                    dgvConjuntos.DataMember = ds.Tables[0].TableName;

                }
                else
                {
                    ds.Clear();

                    string seleciona_p_modelo = "SELECT * FROM tb_conjuntos WHERE modelo_conj = @modelo_conj";

                    SqlCommand select_model = new SqlCommand(seleciona_p_modelo, ClassConexao.connection);

                    select_model.Parameters.AddWithValue("@modelo_conj", cbModelo.SelectedItem.ToString());

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(select_model);

                    dataAdapter.Fill(ds);

                    dgvConjuntos.DataSource = ds;
                    dgvConjuntos.DataMember = ds.Tables[0].TableName;


                }
                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            BuscarConjuntos();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //Criar algoritmo de limpeza de campos
        }

        private void dgvConjuntos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ClassUtilidades._id_conjunto = Convert.ToInt32(dgvConjuntos.Rows[e.RowIndex].Cells[idconjDGVtxtbox.Index].Value);
            ClassUtilidades._veredito_descricao = dgvConjuntos.CurrentRow.Cells[nomeconjDGVtxtbox.Index].Value.ToString();
            ClassUtilidades._cod_conjunto = dgvConjuntos.CurrentRow.Cells[codconjDGVtxtbox.Index].Value.ToString();


            this.Close();
            //this.Close();
        }
    }
}
