﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjetoCompositor
{
    public partial class TelaModelo : Form
    {
        public TelaModelo()
        {
            InitializeComponent();
        }

        private void BtnCadModelo_Click(object sender, EventArgs e)
        {
            try
            {
                TelaMensagem mensagem = new TelaMensagem();

                string inserir = "INSERT INTO tb_modelos(modelo_conj) values (@modelo_conj)";

                SqlCommand insert = new SqlCommand(inserir, ClassConexao.connection);

                insert.Parameters.AddWithValue("@modelo_conj", txtModelo.Text);

                ClassConexao.Aberto();

                if (insert.ExecuteNonQuery() != -1)
                {
                    //Criar form para confirmação de sucesso!!!!!!
                    ClassUtilidades._verificamensagem = 1;
                    
                    mensagem.ShowDialog();

                    //MessageBox.Show("PARABÉNS! VOCÊ CADASTROU O MODELO " + txtModelo.Text, "SUCESSO", MessageBoxButtons.OK,MessageBoxIcon.Information);
                    txtModelo.Clear();
                    //TelaModelo modelo = new TelaModelo();
                }
                else
                {
                    //MessageBox.Show("HOUVE UM ERRO NO CADASTRO DO MODELO!\n REINSIRA O MODELO!", "ATENÇÃO", MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                    ClassUtilidades._verificamensagem = 0;
                    mensagem.ShowDialog();
                }

                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void TelaModelo_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("DESEJA SAIR?", "ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }
    }
}
