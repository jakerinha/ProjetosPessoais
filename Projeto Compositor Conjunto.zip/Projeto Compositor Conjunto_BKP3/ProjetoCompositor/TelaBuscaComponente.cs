﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ProjetoCompositor
{
    public partial class TelaBuscaComponente : Form
    {
        DataSet ds = new DataSet();
        public TelaBuscaComponente()
        {
            InitializeComponent();
            
        }

        private void TelaBuscaComponente_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'bDCompositor_tb_componentes.tb_componentes'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_componentesTableAdapter.Fill(this.bDCompositor_tb_componentes.tb_componentes);
            
            if(ClassUtilidades._TelaComponente == 0)
            {
                txtDescricao.Text = ClassUtilidades._nomeComp;
                BuscaComp();
            }
        }

        private void BuscaComp()
        {
            try
            {
                ClassConexao.Aberto();
                string selecionar;

                //Limpando DATA GRID VIEW
                dgvBuscaComp.DataSource = ds;
                ds.Clear();

                if (txtID.Text != "")
                {
                    selecionar = "SELECT * FROM tb_componentes WHERE id_comp like '%"+txtID.Text+"%'";

                    SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);
                    
                    if ((int)select.ExecuteScalar() != -1)
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(select);

                        dataAdapter.Fill(ds);

                        dgvBuscaComp.DataSource = ds;
                        dgvBuscaComp.DataMember = ds.Tables[0].TableName;

                    }
                    else
                    {
                        MessageBox.Show("HOUVE UM ERRO NA BUSCA DO COMPONENTE.\n", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else if(txtCodComp.Text != "")
                {
                    selecionar = "SELECT * FROM tb_componentes WHERE cod_comp like '%" + txtCodComp.Text + "%'";

                    SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                    if ((int)select.ExecuteScalar() != -1)
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(select);

                        dataAdapter.Fill(ds);

                        dgvBuscaComp.DataSource = ds;
                        dgvBuscaComp.DataMember = ds.Tables[0].TableName;

                    }
                    else
                    {
                        MessageBox.Show("HOUVE UM ERRO NA BUSCA DO COMPONENTE.\n", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else if(txtDescricao.Text != "")
                {
                    
                    selecionar = "SELECT * FROM tb_componentes WHERE nome_comp like '%" + txtDescricao.Text + "%'";

                    SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                    if ((int)select.ExecuteScalar() != -1)
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(select);

                        dataAdapter.Fill(ds);

                        dgvBuscaComp.DataSource = ds;
                        dgvBuscaComp.DataMember = ds.Tables[0].TableName;

                    }
                    else
                    {
                        MessageBox.Show("HOUVE UM ERRO NA BUSCA DO COMPONENTE.\n", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    selecionar = "SELECT * FROM tb_componentes";

                    SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                    if ((int)select.ExecuteScalar() != -1)
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(select);

                        dataAdapter.Fill(ds);

                        dgvBuscaComp.DataSource = ds;
                        dgvBuscaComp.DataMember = ds.Tables[0].TableName;

                    }
                    else
                    {
                        MessageBox.Show("HOUVE UM ERRO NA BUSCA DO COMPONENTE.\n", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void BtnBusca_Click(object sender, EventArgs e)
        {
            BuscaComp();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtID.Clear();
            txtDescricao.Clear();
            txtCodComp.Clear();
        }

        private void DgvBuscaComp_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (ClassUtilidades._TelaComponente == 1)
            {
                ClassUtilidades._codComp = dgvBuscaComp.Rows[e.RowIndex].Cells[codcompDGVColuna.Index].Value.ToString();
                ClassUtilidades._nomeComp = dgvBuscaComp.Rows[e.RowIndex].Cells[nomecompDGVColuna.Index].Value.ToString();


                TelaQuantidade quantidade = new TelaQuantidade();
                quantidade.ShowDialog();
            }
            else
            {
                ClassUtilidades._codComp = dgvBuscaComp.Rows[e.RowIndex].Cells[codcompDGVColuna.Index].Value.ToString();
                ClassUtilidades._nomeComp = dgvBuscaComp.Rows[e.RowIndex].Cells[nomecompDGVColuna.Index].Value.ToString();

            }

            this.Close();
        }
    }
}
