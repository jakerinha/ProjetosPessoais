﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ProjetoCompositor
{
    class ClassUtilidades
    {

        //SESSÃO USUÁRIO

        public static string _usuario;
        public static string _perfil;


        //SESSÃO COMPONENTES
        //public static int _IdentificadorComp;
        public static string _codComp;
        public static string _nomeComp;
        public static int _qtdeComp;
        public static int _TelaComponente;

        //SESSÃO MENSAGEM
        public static int _verificamensagem;

        //SESSÃO CONJUNTOS

        public static string _descricao_conjunto;
        public static int _id_conjunto;
        public static string _veredito_descricao;
        public static string _cod_conjunto;


        //SESSÃO SQLDATA
        public static SqlDataReader DataReader;

    }
}

