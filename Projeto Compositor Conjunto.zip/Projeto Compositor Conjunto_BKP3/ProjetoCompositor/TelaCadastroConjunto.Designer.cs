﻿namespace ProjetoCompositor
{
    partial class TelaCadastroConjunto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbModelo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCodConjunto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDescricaoComp = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCodComp = new System.Windows.Forms.TextBox();
            this.txtIDcomp = new System.Windows.Forms.TextBox();
            this.btnInserirComp = new System.Windows.Forms.Button();
            this.dgvComp = new System.Windows.Forms.DataGridView();
            this.idcompDGVColuna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codcompDGVColuna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomecompDGVColuna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtdecompDGVColuna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbcomponentesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bDCompositor_tb_componentes = new ProjetoCompositor.BDCompositor_tb_componentes();
            this.btnCadConj = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.tb_componentesTableAdapter = new ProjetoCompositor.BDCompositor_tb_componentesTableAdapters.tb_componentesTableAdapter();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbcomponentesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDCompositor_tb_componentes)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbModelo);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtDescricao);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtCodConjunto);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtID);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(404, 125);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados do Conjunto";
            // 
            // cbModelo
            // 
            this.cbModelo.FormattingEnabled = true;
            this.cbModelo.Location = new System.Drawing.Point(280, 80);
            this.cbModelo.Name = "cbModelo";
            this.cbModelo.Size = new System.Drawing.Size(118, 21);
            this.cbModelo.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Descrição do Conjunto";
            // 
            // txtDescricao
            // 
            this.txtDescricao.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescricao.Location = new System.Drawing.Point(23, 81);
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(251, 20);
            this.txtDescricao.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(277, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Modelo";
            // 
            // txtCodConjunto
            // 
            this.txtCodConjunto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCodConjunto.Location = new System.Drawing.Point(64, 42);
            this.txtCodConjunto.Name = "txtCodConjunto";
            this.txtCodConjunto.Size = new System.Drawing.Size(140, 20);
            this.txtCodConjunto.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Código do Conjunto";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(23, 42);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(32, 20);
            this.txtID.TabIndex = 1;
            this.txtID.TabStop = false;
            this.txtID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtDescricaoComp);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtCodComp);
            this.groupBox2.Controls.Add(this.txtIDcomp);
            this.groupBox2.Controls.Add(this.btnInserirComp);
            this.groupBox2.Controls.Add(this.dgvComp);
            this.groupBox2.Location = new System.Drawing.Point(12, 143);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(404, 211);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Componentes";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(166, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Descrição";
            // 
            // txtDescricaoComp
            // 
            this.txtDescricaoComp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescricaoComp.Location = new System.Drawing.Point(169, 44);
            this.txtDescricaoComp.Name = "txtDescricaoComp";
            this.txtDescricaoComp.Size = new System.Drawing.Size(229, 20);
            this.txtDescricaoComp.TabIndex = 6;
            this.txtDescricaoComp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BuscarComp);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(64, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Cód. Comp";
            // 
            // txtCodComp
            // 
            this.txtCodComp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCodComp.Location = new System.Drawing.Point(67, 44);
            this.txtCodComp.Name = "txtCodComp";
            this.txtCodComp.Size = new System.Drawing.Size(94, 20);
            this.txtCodComp.TabIndex = 5;
            this.txtCodComp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BuscarComp);
            // 
            // txtIDcomp
            // 
            this.txtIDcomp.Location = new System.Drawing.Point(12, 44);
            this.txtIDcomp.Name = "txtIDcomp";
            this.txtIDcomp.Size = new System.Drawing.Size(49, 20);
            this.txtIDcomp.TabIndex = 4;
            this.txtIDcomp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BuscarComp);
            // 
            // btnInserirComp
            // 
            this.btnInserirComp.BackgroundImage = global::ProjetoCompositor.Properties.Resources.Pesquisar;
            this.btnInserirComp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnInserirComp.Location = new System.Drawing.Point(366, 13);
            this.btnInserirComp.Name = "btnInserirComp";
            this.btnInserirComp.Size = new System.Drawing.Size(32, 25);
            this.btnInserirComp.TabIndex = 7;
            this.btnInserirComp.UseVisualStyleBackColor = true;
            this.btnInserirComp.Click += new System.EventHandler(this.BtnInserirComp_Click);
            // 
            // dgvComp
            // 
            this.dgvComp.AllowUserToAddRows = false;
            this.dgvComp.AllowUserToDeleteRows = false;
            this.dgvComp.AutoGenerateColumns = false;
            this.dgvComp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvComp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idcompDGVColuna,
            this.codcompDGVColuna,
            this.nomecompDGVColuna,
            this.qtdecompDGVColuna});
            this.dgvComp.DataSource = this.tbcomponentesBindingSource;
            this.dgvComp.Location = new System.Drawing.Point(15, 70);
            this.dgvComp.Name = "dgvComp";
            this.dgvComp.ReadOnly = true;
            this.dgvComp.Size = new System.Drawing.Size(379, 128);
            this.dgvComp.TabIndex = 0;
            // 
            // idcompDGVColuna
            // 
            this.idcompDGVColuna.DataPropertyName = "id_comp";
            this.idcompDGVColuna.HeaderText = "ID";
            this.idcompDGVColuna.Name = "idcompDGVColuna";
            this.idcompDGVColuna.ReadOnly = true;
            this.idcompDGVColuna.Width = 35;
            // 
            // codcompDGVColuna
            // 
            this.codcompDGVColuna.DataPropertyName = "cod_comp";
            this.codcompDGVColuna.HeaderText = "Cód Comp.";
            this.codcompDGVColuna.Name = "codcompDGVColuna";
            this.codcompDGVColuna.ReadOnly = true;
            this.codcompDGVColuna.Width = 50;
            // 
            // nomecompDGVColuna
            // 
            this.nomecompDGVColuna.DataPropertyName = "nome_comp";
            this.nomecompDGVColuna.HeaderText = "Descrição";
            this.nomecompDGVColuna.Name = "nomecompDGVColuna";
            this.nomecompDGVColuna.ReadOnly = true;
            this.nomecompDGVColuna.Width = 175;
            // 
            // qtdecompDGVColuna
            // 
            this.qtdecompDGVColuna.HeaderText = "Qtde Comp.";
            this.qtdecompDGVColuna.Name = "qtdecompDGVColuna";
            this.qtdecompDGVColuna.ReadOnly = true;
            this.qtdecompDGVColuna.Width = 75;
            // 
            // tbcomponentesBindingSource
            // 
            this.tbcomponentesBindingSource.DataMember = "tb_componentes";
            this.tbcomponentesBindingSource.DataSource = this.bDCompositor_tb_componentes;
            // 
            // bDCompositor_tb_componentes
            // 
            this.bDCompositor_tb_componentes.DataSetName = "BDCompositor_tb_componentes";
            this.bDCompositor_tb_componentes.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnCadConj
            // 
            this.btnCadConj.Location = new System.Drawing.Point(24, 360);
            this.btnCadConj.Name = "btnCadConj";
            this.btnCadConj.Size = new System.Drawing.Size(66, 38);
            this.btnCadConj.TabIndex = 8;
            this.btnCadConj.Text = "Cadastrar Conjunto";
            this.btnCadConj.UseVisualStyleBackColor = true;
            this.btnCadConj.Click += new System.EventHandler(this.BtnCadConj_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(98, 360);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(62, 38);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // tb_componentesTableAdapter
            // 
            this.tb_componentesTableAdapter.ClearBeforeFill = true;
            // 
            // TelaCadastroConjunto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 411);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCadConj);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "TelaCadastroConjunto";
            this.Text = "Cadastro de Conjuntos";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TelaCadastroConjunto_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbcomponentesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDCompositor_tb_componentes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDescricao;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCodConjunto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvComp;
        private System.Windows.Forms.Button btnInserirComp;
        private System.Windows.Forms.Button btnCadConj;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.ComboBox cbModelo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDescricaoComp;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCodComp;
        private System.Windows.Forms.TextBox txtIDcomp;
        private BDCompositor_tb_componentes bDCompositor_tb_componentes;
        private System.Windows.Forms.BindingSource tbcomponentesBindingSource;
        private BDCompositor_tb_componentesTableAdapters.tb_componentesTableAdapter tb_componentesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idcompDGVColuna;
        private System.Windows.Forms.DataGridViewTextBoxColumn codcompDGVColuna;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomecompDGVColuna;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtdecompDGVColuna;
    }
}