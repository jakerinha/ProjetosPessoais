﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjetoCompositor
{
    public partial class TelaCadastroConjunto : Form
    {
        DataSet ds = new DataSet();
        int i = 0;
        int id;
        public TelaCadastroConjunto()
        {
            InitializeComponent();

            BuscarIDconjunto();
            BuscarModelos();

        }

        private void BtnCadConj_Click(object sender, EventArgs e)
        {
            try
            {
                ClassConexao.Aberto();
                int i;
                TelaMensagem mensagem = new TelaMensagem();

                string inserir_conj = "INSERT INTO tb_conjuntos(cod_conj, nome_conj, modelo_conj) values (@cod_conj, @nome_conj, @modelo_conj)";


                //O id_conj desse comando não é auto incremental, logo ele receberá o id referente ao conjunto.
                string inserir_conj_comp = "INSERT INTO tb_conjuntos_componentes(id_conj, id_comp, nome_comp, qtde_comp) values (@id_conj, @id_comp, @nome_comp, @qtde_comp)";

                SqlCommand insertconj = new SqlCommand(inserir_conj, ClassConexao.connection);
                SqlCommand insertconjcomp = new SqlCommand(inserir_conj_comp, ClassConexao.connection);

                

                insertconj.Parameters.AddWithValue("@cod_conj", txtCodConjunto.Text);
                insertconj.Parameters.AddWithValue("@nome_conj", txtDescricao.Text);
                insertconj.Parameters.AddWithValue("@modelo_conj", cbModelo.SelectedItem);

                if(insertconj.ExecuteNonQuery() != -1)
                {

                    for (i = 0; i < dgvComp.RowCount; i++)
                    {
                        insertconjcomp.Parameters.Clear();

                        //Continuar o código de inserção de dados no BD com relacionamento
                        //Verificar campo txtID <-- ID DO CONJUNTO
                        insertconjcomp.Parameters.AddWithValue("@id_conj", txtID.Text);
                        insertconjcomp.Parameters.AddWithValue("@id_comp", dgvComp.Rows[i].Cells[idcompDGVColuna.Index].Value.ToString());
                        insertconjcomp.Parameters.AddWithValue("@nome_comp", dgvComp.Rows[i].Cells[nomecompDGVColuna.Index].Value.ToString());
                        insertconjcomp.Parameters.AddWithValue("@qtde_comp", dgvComp.Rows[i].Cells[qtdecompDGVColuna.Index].Value.ToString());

                        insertconjcomp.ExecuteNonQuery();
                    }
                    //Mensagem de Sucesso
                    ClassUtilidades._verificamensagem = 1;
                    mensagem.ShowDialog();
                    id++;
                    txtID.Text = id.ToString();
                    Limpar();
                }
                else
                {
                    //Mensagem de Sucesso
                    ClassUtilidades._verificamensagem = 0;
                    mensagem.ShowDialog();
                    Limpar();
                }
                
                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void BuscarModelos()
        {
            try
            {
                int i;
                string selecionar = "SELECT * FROM tb_modelos";

                SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                ClassConexao.Aberto();

                SqlDataReader dataReader = select.ExecuteReader();

                
                for (i = 0; dataReader.Read() == true; i++)
                {
                    cbModelo.Items.Insert(i, dataReader.GetString(0));
                }
                
                dataReader.Close();
                dataReader.Dispose();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void BtnInserirComp_Click(object sender, EventArgs e)
        {
            
            try
            {
                //Cria a partir da Classe TelaBuscaComponente, um objeto buscaComponente
                TelaBuscaComponente buscaComponente = new TelaBuscaComponente();
                
                //Varíavel pertencente a Classe ClassUtilidades para verificar por qual entrada foi solicitada o componente
                ClassUtilidades._TelaComponente = 1;
                //Abre a tela buscaComponente ----> TelaBuscaComponente
                buscaComponente.ShowDialog();

                if (String.IsNullOrEmpty(ClassUtilidades._codComp) != false)
                {
                    
                }
                else
                {
                    string selecionar = "SELECT * FROM tb_componentes where cod_comp = '" + ClassUtilidades._codComp + "'";

                    SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                    ClassConexao.Aberto();

                    if ((int)select.ExecuteScalar() != -1)
                    {
                        SqlDataAdapter da = new SqlDataAdapter(select);
                        da.Fill(ds);

                        dgvComp.DataSource = ds;
                        dgvComp.DataMember = ds.Tables[0].TableName;
                        dgvComp.Rows[i].Cells[qtdecompDGVColuna.Index].Value = ClassUtilidades._qtdeComp;

                        i++;
                    }
                    else
                    {
                        MessageBox.Show("HOUVE UM ERRO NA INSERÇÃO DO COMPONENTE NA PLANILHA!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    ClassUtilidades._codComp = "";
                    ClassConexao.Fechar();

                }
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }

        }

        private void BuscarComp_Enter()
        {
            try
            {
                ClassConexao.Aberto();

                string selecionar;

                TelaQuantidade quantidade = new TelaQuantidade();


                if (txtIDcomp.Text != "")
                {
                    selecionar = "SELECT * FROM tb_componentes WHERE id_comp like '" + txtIDcomp.Text + "'";

                    SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                    if ((int)select.ExecuteScalar() != -1)
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(select);

                        dataAdapter.Fill(ds);

                        dgvComp.DataSource = ds;
                        dgvComp.DataMember = ds.Tables[0].TableName;
                        quantidade.ShowDialog();
                        dgvComp.Rows[i].Cells[qtdecompDGVColuna.Index].Value = ClassUtilidades._qtdeComp;
                        i++;
                        txtIDcomp.Clear();
                    }
                    else
                    {
                        MessageBox.Show("HOUVE UM ERRO NA BUSCA DO COMPONENTE.\n", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else if (txtCodComp.Text != "")
                {
                    selecionar = "SELECT * FROM tb_componentes WHERE cod_comp like '" + txtCodComp.Text + "'";

                    SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                    if ((int)select.ExecuteScalar() != -1)
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(select);

                        dataAdapter.Fill(ds);

                        dgvComp.DataSource = ds;
                        dgvComp.DataMember = ds.Tables[0].TableName;
                        quantidade.ShowDialog();
                        dgvComp.Rows[i].Cells[qtdecompDGVColuna.Index].Value = ClassUtilidades._qtdeComp;
                        txtCodComp.Clear();
                        i++;

                    }
                    else
                    {
                        MessageBox.Show("HOUVE UM ERRO NA BUSCA DO COMPONENTE.\n", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else if (txtDescricaoComp.Text != "")
                {
                    selecionar = "SELECT * FROM tb_componentes WHERE nome_comp like '" + txtDescricaoComp.Text + "'";

                    SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                    if ((int)select.ExecuteScalar() != -1)
                    {
                        SqlDataAdapter dataAdapter = new SqlDataAdapter(select);

                        dataAdapter.Fill(ds);

                        dgvComp.DataSource = ds;
                        dgvComp.DataMember = ds.Tables[0].TableName;
                        quantidade.ShowDialog();
                        dgvComp.Rows[i].Cells[qtdecompDGVColuna.Index].Value = ClassUtilidades._qtdeComp;
                        txtDescricaoComp.Clear();
                        i++;
                    }
                    else
                    {
                        MessageBox.Show("HOUVE UM ERRO NA BUSCA DO COMPONENTE.\n", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("CAMPO NÃO PODE SER VÁZIO!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void BuscarComp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BuscarComp_Enter();
            }
        }

        private void TelaCadastroConjunto_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(MessageBox.Show("VOCÊ TEM CERTEZA QUE DESEJA SAIR?", "ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.No)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
            
            
        }
        private void BuscarIDconjunto()
        {
            try
            {
                ClassConexao.Aberto();


                string selecionar = "SELECT TOP 1 id_conj FROM tb_conjuntos ORDER BY id_conj desc";

                SqlCommand buscaid = new SqlCommand(selecionar, ClassConexao.connection);

                //SqlDataReader dataReader = buscaid.ExecuteReader();

                id = Convert.ToInt32(buscaid.ExecuteScalar()) + 1;
                txtID.Text = id.ToString();

                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            Limpar();
        }

        private void Limpar()
        {
            dgvComp.DataSource = ds;
            ds.Clear();

            txtDescricao.Clear();
            txtCodConjunto.Clear();
            txtCodComp.Clear();
            txtDescricaoComp.Clear();
            txtIDcomp.Clear();
            cbModelo.Text = "";
        }
    }
}
