﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ProjetoCompositor
{
    public partial class TelaEntrada : Form
    {
        
        //int id;
        int qtd_anterior;
        uint quantia_desejada;
        //TelaQuantidade quantidade = new TelaQuantidade();
        TelaMensagem mensagem = new TelaMensagem();
        //TelaEntrada entrada = new TelaEntrada();


        public TelaEntrada()
        {
            InitializeComponent();
        }

        private void BuscaComponenteID()
        {
            try
            {
                ClassConexao.Aberto();

                
                if (String.IsNullOrEmpty(txtCODcomp.Text) == true)
                {
                    MessageBox.Show("O campo do ID do componente está vázio!", "ATENÇÃO!");
                    ClassUtilidades.DataReader.Close();
                }
                else
                {
                    string seleciona_p_cod = "SELECT nome_comp, qtd_comp FROM tb_componentes WHERE cod_comp = @cod_comp";

                    SqlCommand select_cod = new SqlCommand(seleciona_p_cod, ClassConexao.connection);

                    select_cod.Parameters.AddWithValue("@cod_comp", txtCODcomp.Text);

                    ClassUtilidades.DataReader = select_cod.ExecuteReader();

                    if (ClassUtilidades.DataReader.Read() == true)
                    {
                        txtDescricaoComp.Text = ClassUtilidades.DataReader.GetString(0);
                        qtd_anterior = ClassUtilidades.DataReader.GetInt32(1);
                        ClassUtilidades.DataReader.Close();
                        txtDescricaoComp.Enabled = false;
                        txtCODcomp.Enabled = false;
                        txtQtdeEntrada.Focus();

                    }
                    else
                    {
                        
                        MessageBox.Show("Leitura de valores não foi efetuada!", "ATENÇÃO!");
                        ClassUtilidades.DataReader.Close();
                        txtCODcomp.Clear();
                    }

                }

                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
                ClassUtilidades.DataReader.Close();
            }
        }
        private void BuscaComponenteNOME()
        {
            try
            {
               
                if (String.IsNullOrEmpty(txtDescricaoComp.Text) == true)
                {
                    MessageBox.Show("O campo do NOME do componente está vázio!", "ATENÇÃO!");
                    ClassUtilidades.DataReader.Close();
                }
                else
                {
                    ClassConexao.Aberto();

                    string seleciona_p_nome = "SELECT cod_comp, qtd_comp FROM tb_componentes WHERE nome_comp like '%" + txtDescricaoComp.Text + "%'";

                    SqlCommand select_nome = new SqlCommand(seleciona_p_nome, ClassConexao.connection);

                    //select_nome.Parameters.AddWithValue("@nome_comp", txtDescricaoComp.Text);

                    ClassUtilidades.DataReader = select_nome.ExecuteReader();

                    if (ClassUtilidades.DataReader.Read() != false)
                    {
                        txtCODcomp.Text = ClassUtilidades.DataReader.GetString(0);
                        qtd_anterior = ClassUtilidades.DataReader.GetInt32(1);
                        ClassUtilidades.DataReader.Close();

                        txtDescricaoComp.Enabled = false;
                        txtCODcomp.Enabled = false;
                        txtQtdeEntrada.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Leitura de valores não foi efetuada!", "ATENÇÃO!");
                        ClassUtilidades.DataReader.Close();
                        txtDescricaoComp.Clear();
                    }
                    ClassConexao.Fechar();
                }

            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
                ClassUtilidades.DataReader.Close();
            }
        }
        private void AtualizarEstoqueID()
        {
            try
            {
                //string qtd_anterior;
                

                if (Convert.ToInt32(txtQtdeEntrada.Text) <= 0)
                {
                    MessageBox.Show("Entrada não pode ser negativa ou vázia!", "ATENÇÃO");
                }
                else
                {
                    ClassConexao.Aberto();

                    string atualizar_estoque = "UPDATE tb_componentes SET qtd_comp = @qtd_comp WHERE cod_comp = @cod_comp";

                    SqlCommand update = new SqlCommand(atualizar_estoque, ClassConexao.connection);

                    //Atualiza os valores no BD
                    quantia_desejada = (uint)Convert.ToInt32(txtQtdeEntrada.Text);
                    
                    update.Parameters.AddWithValue("@qtd_comp", quantia_desejada + qtd_anterior);

                    update.Parameters.AddWithValue("@cod_comp", txtCODcomp.Text);

                    if (update.ExecuteNonQuery() != -1)
                    {
                        ClassUtilidades._verificamensagem = 1;
                        mensagem.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        ClassUtilidades._verificamensagem = 0;
                        mensagem.ShowDialog();
                        this.Close();
                    }
                    ClassConexao.Fechar();
                }
                
            }
            catch (Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }
        

        /*  private void BuscaIDentrada()
          {
              try
              {
                  ClassConexao.Aberto();

                  string selecionar = "";
                  //Criar tabela de movimentação.......

                  ClassConexao.Fechar();
              }
              catch(Exception msg1)
              {
                  MessageBox.Show(msg1.Message);
              }
          }
          */
        
        private void TelaEntrada_Load(object sender, EventArgs e)
        {
            txtDataAtual.Text = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
        }

        private void btnGerarEntrada_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtNumNota.Text) != false )
            {
                MessageBox.Show("Número da NOTA FISCAL não pode ser vázio!", "ATENÇÃO");
            }else if (String.IsNullOrEmpty(txtCODcomp.Text) != false)
            {
                MessageBox.Show("Código do Componente a dar ENTRADA não pode ser vázio!", "ATENÇÃO");
            }
            else if(String.IsNullOrEmpty(txtDescricaoComp.Text) != false)
            {
                MessageBox.Show("Descrição do Componente a dar ENTRADA não pode ser vázio!", "ATENÇÃO");
            }
            else
            {
                EntradaComponente();
            }
        }

        private void txtIDcomp_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BuscaComponenteID();
                
            }
        }

        private void txtDescricaoComp_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BuscaComponenteNOME();
                
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtDescricaoComp.Clear();
            txtCODcomp.Clear();
            txtQtdeEntrada.Clear();
            txtNumNota.Clear();
            txtCODcomp.Enabled = true;
            txtDescricaoComp.Enabled = true;
        }

        private void btnBuscaComp_Click(object sender, EventArgs e)
        {
            TelaBuscaComponente telaBusca = new TelaBuscaComponente();
            ClassUtilidades._TelaComponente = 0;
            telaBusca.ShowDialog();
            txtDescricaoComp.Text = ClassUtilidades._nomeComp;
            txtCODcomp.Text = ClassUtilidades._codComp;

            txtDescricaoComp.Enabled = false;
            txtCODcomp.Enabled = false;
            txtQtdeEntrada.Focus();
        }
        private void EntradaComponente()
        {
            try
            {

                ClassConexao.Aberto();

                string inserir_entrada = "INSERT INTO tb_movimentacao (num_notafiscal, data_emissao_nota, data_entrada, cod_material, descricao_mov, qtd_mov, status_mov, usuario_mov) values (@num_notafiscal, @data_emissao_nota, @data_entrada, @cod_material, @descricao_mov, @qtd_mov, @status_mov, @usuario_mov)";

                SqlCommand insert_enter = new SqlCommand(inserir_entrada, ClassConexao.connection);

                insert_enter.Parameters.AddWithValue("@num_notafiscal", txtNumNota.Text);
                insert_enter.Parameters.AddWithValue("@data_emissao_nota", dtpEmissao.Value.Date);
                insert_enter.Parameters.AddWithValue("@data_entrada", txtDataAtual.Text);
                insert_enter.Parameters.AddWithValue("@cod_material", txtCODcomp.Text);
                insert_enter.Parameters.AddWithValue("@descricao_mov", txtDescricaoComp.Text);
                insert_enter.Parameters.AddWithValue("@qtd_mov", Convert.ToInt32(txtQtdeEntrada.Text));
                insert_enter.Parameters.AddWithValue("@status_mov", "E");
                insert_enter.Parameters.AddWithValue("@usuario_mov", ClassUtilidades._usuario);

                if (insert_enter.ExecuteNonQuery() != -1)
                {
                    AtualizarEstoqueID();
                    //MessageBox.Show("Gerando Entrada......");
                    //Pensar em documentar entradas em arquivos de xls, ou Excel.
                }
                else
                {
                    MessageBox.Show("Ocorreu um erro na geração da ENTRADA!", "ATENÇÃO");
                }

                ClassConexao.Fechar();

            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void txtNumNota_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Não permite caracteres de serem digitados, mas permite a tecla backspace ser apertada
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)8)
            {
                e.Handled = true;
            }
        }
    }
}
