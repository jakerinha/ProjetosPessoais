﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjetoCompositor
{
    public partial class TelaCadastroFuncionario : Form
    {
        int id;
        public TelaCadastroFuncionario()
        {
            InitializeComponent();

            try
            {

                ClassConexao.Aberto();

                string selecionar = "SELECT top 1 id_func from tb_funcionarios order by id_func desc";
                SqlCommand select = new SqlCommand(selecionar, ClassConexao.connection);

                id = Convert.ToInt32(select.ExecuteScalar()) + 1;
                txtID.Text = id.ToString();

                ClassConexao.Fechar();

            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }


        }

        private void BtnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                TelaMensagem mensagem = new TelaMensagem();

                string inserir = "INSERT INTO tb_funcionarios(nome_func,perfil_func,usuario_func,senha_func) values (@nome_func, @perfil_func,@usuario_func,@senha_func)";

                //string selecionar = "SELECT usuario_func FROM tb_funcionarios where usuario_func = @usuario_func";

                SqlCommand insert = new SqlCommand(inserir, ClassConexao.connection);
                
                ClassConexao.Aberto();
                //Recebendo valores para inserção
                insert.Parameters.AddWithValue("@nome_func", txtNomeFunc.Text);

                if (rbGerente.Checked == true)
                {
                    insert.Parameters.AddWithValue("@perfil_func", "GERENTE");
                }
                else
                {
                    insert.Parameters.AddWithValue("@perfil_func", "AUXILIAR");
                }

                insert.Parameters.AddWithValue("@usuario_func", txtUsuarioFunc.Text);
                insert.Parameters.AddWithValue("@senha_func", txtSenhaFunc.Text);

                /*
                Colocar comparação com o nome de usuário a ser cadastrado....
                Senha, nome do funcionário, perfil pode repetir!!!!
                */


                if (insert.ExecuteNonQuery() != 0)
                {
                    //MessageBox.Show("FUNCIONÁRIO CADASTRADO COM SUCESSO!", "ATENÇÃO!");

                    //TELA DE MENSAGEM

                    ClassUtilidades._verificamensagem = 1;
                    mensagem.ShowDialog();

                    //Colocar campos a serem limpos!!!
                    id++;
                    txtID.Text = id.ToString();
                    txtNomeFunc.Clear();
                    txtSenhaFunc.Clear();
                    txtUsuarioFunc.Clear();

                    if (rbGerente.Checked == true)
                    {
                        rbGerente.Checked = false;
                    }
                    else
                    {
                        rbAuxiliar.Checked = false;
                    }
                }
                else
                {
                    //MessageBox.Show("HOUVE UM ERRO NO CADASTRO!", "ATENÇÃO!",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);

                    ClassUtilidades._verificamensagem = 0;
                    mensagem.ShowDialog();
                }
                ClassConexao.Fechar();

            }
            catch (Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void TelaCadastroFuncionario_FormClosing(object sender, FormClosingEventArgs e)
        {

            try
            {
                if(MessageBox.Show("TEM CERTEZA QUE DESEJA SAIR?", "ATENÇÃO", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }


        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNomeFunc.Clear();
            txtSenhaFunc.Clear();
            txtUsuarioFunc.Clear();
            if (rbGerente.Checked == true)
            {
                rbGerente.Checked = false;
            }
            else
            {
                rbAuxiliar.Checked = false;
            }
        }
    }
}
