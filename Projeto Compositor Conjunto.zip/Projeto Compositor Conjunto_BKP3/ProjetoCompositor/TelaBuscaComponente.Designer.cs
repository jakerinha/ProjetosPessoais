﻿namespace ProjetoCompositor
{
    partial class TelaBuscaComponente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnBusca = new System.Windows.Forms.Button();
            this.txtDescricao = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCodComp = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvBuscaComp = new System.Windows.Forms.DataGridView();
            this.idcompDGVColuna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codcompDGVColuna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomecompDGVColuna = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbcomponentesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bDCompositor_tb_componentes = new ProjetoCompositor.BDCompositor_tb_componentes();
            this.tb_componentesTableAdapter = new ProjetoCompositor.BDCompositor_tb_componentesTableAdapters.tb_componentesTableAdapter();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuscaComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbcomponentesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDCompositor_tb_componentes)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLimpar);
            this.groupBox1.Controls.Add(this.btnBusca);
            this.groupBox1.Controls.Add(this.txtDescricao);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtCodComp);
            this.groupBox1.Controls.Add(this.txtID);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(427, 93);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filtro";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(21, 58);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(50, 23);
            this.btnLimpar.TabIndex = 5;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnBusca
            // 
            this.btnBusca.Location = new System.Drawing.Point(366, 58);
            this.btnBusca.Name = "btnBusca";
            this.btnBusca.Size = new System.Drawing.Size(47, 23);
            this.btnBusca.TabIndex = 4;
            this.btnBusca.Text = "Buscar";
            this.btnBusca.UseVisualStyleBackColor = true;
            this.btnBusca.Click += new System.EventHandler(this.BtnBusca_Click);
            // 
            // txtDescricao
            // 
            this.txtDescricao.Location = new System.Drawing.Point(193, 32);
            this.txtDescricao.Name = "txtDescricao";
            this.txtDescricao.Size = new System.Drawing.Size(220, 20);
            this.txtDescricao.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(190, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Descrição Componente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Código Componente";
            // 
            // txtCodComp
            // 
            this.txtCodComp.Location = new System.Drawing.Point(60, 32);
            this.txtCodComp.Name = "txtCodComp";
            this.txtCodComp.Size = new System.Drawing.Size(127, 20);
            this.txtCodComp.TabIndex = 2;
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(21, 32);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(32, 20);
            this.txtID.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvBuscaComp);
            this.groupBox2.Location = new System.Drawing.Point(12, 111);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(427, 204);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Componentes";
            // 
            // dgvBuscaComp
            // 
            this.dgvBuscaComp.AllowUserToAddRows = false;
            this.dgvBuscaComp.AllowUserToDeleteRows = false;
            this.dgvBuscaComp.AutoGenerateColumns = false;
            this.dgvBuscaComp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBuscaComp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idcompDGVColuna,
            this.codcompDGVColuna,
            this.nomecompDGVColuna});
            this.dgvBuscaComp.DataSource = this.tbcomponentesBindingSource;
            this.dgvBuscaComp.Location = new System.Drawing.Point(12, 17);
            this.dgvBuscaComp.Name = "dgvBuscaComp";
            this.dgvBuscaComp.ReadOnly = true;
            this.dgvBuscaComp.Size = new System.Drawing.Size(401, 181);
            this.dgvBuscaComp.TabIndex = 0;
            this.dgvBuscaComp.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvBuscaComp_CellDoubleClick);
            // 
            // idcompDGVColuna
            // 
            this.idcompDGVColuna.DataPropertyName = "id_comp";
            this.idcompDGVColuna.HeaderText = "ID";
            this.idcompDGVColuna.Name = "idcompDGVColuna";
            this.idcompDGVColuna.ReadOnly = true;
            // 
            // codcompDGVColuna
            // 
            this.codcompDGVColuna.DataPropertyName = "cod_comp";
            this.codcompDGVColuna.HeaderText = "CÓD COMP.";
            this.codcompDGVColuna.Name = "codcompDGVColuna";
            this.codcompDGVColuna.ReadOnly = true;
            // 
            // nomecompDGVColuna
            // 
            this.nomecompDGVColuna.DataPropertyName = "nome_comp";
            this.nomecompDGVColuna.HeaderText = "DESCRIÇÃO";
            this.nomecompDGVColuna.Name = "nomecompDGVColuna";
            this.nomecompDGVColuna.ReadOnly = true;
            this.nomecompDGVColuna.Width = 155;
            // 
            // tbcomponentesBindingSource
            // 
            this.tbcomponentesBindingSource.DataMember = "tb_componentes";
            this.tbcomponentesBindingSource.DataSource = this.bDCompositor_tb_componentes;
            // 
            // bDCompositor_tb_componentes
            // 
            this.bDCompositor_tb_componentes.DataSetName = "BDCompositor_tb_componentes";
            this.bDCompositor_tb_componentes.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_componentesTableAdapter
            // 
            this.tb_componentesTableAdapter.ClearBeforeFill = true;
            // 
            // TelaBuscaComponente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 327);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "TelaBuscaComponente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Buscar Componente";
            this.Load += new System.EventHandler(this.TelaBuscaComponente_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBuscaComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbcomponentesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDCompositor_tb_componentes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtDescricao;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCodComp;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvBuscaComp;
        private BDCompositor_tb_componentes bDCompositor_tb_componentes;
        private System.Windows.Forms.BindingSource tbcomponentesBindingSource;
        private BDCompositor_tb_componentesTableAdapters.tb_componentesTableAdapter tb_componentesTableAdapter;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnBusca;
        private System.Windows.Forms.DataGridViewTextBoxColumn idcompDGVColuna;
        private System.Windows.Forms.DataGridViewTextBoxColumn codcompDGVColuna;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomecompDGVColuna;
    }
}