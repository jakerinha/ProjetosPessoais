﻿namespace ProjetoCompositor
{
    partial class TelaSaida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxAtorAjuste = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxDataAjuste = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxIDAjuste = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblFutura = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblAtual = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnPesquisarComp = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtBoxQtdComp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoxDescricaoComp = new System.Windows.Forms.TextBox();
            this.txtBoxCodComp = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbSubtracao = new System.Windows.Forms.RadioButton();
            this.rbAdicao = new System.Windows.Forms.RadioButton();
            this.btnAjustar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtBoxAtorAjuste);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtBoxDataAjuste);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtBoxIDAjuste);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 116);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados de Ajuste";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Ator";
            // 
            // txtBoxAtorAjuste
            // 
            this.txtBoxAtorAjuste.Location = new System.Drawing.Point(19, 80);
            this.txtBoxAtorAjuste.Name = "txtBoxAtorAjuste";
            this.txtBoxAtorAjuste.ReadOnly = true;
            this.txtBoxAtorAjuste.Size = new System.Drawing.Size(176, 20);
            this.txtBoxAtorAjuste.TabIndex = 4;
            this.txtBoxAtorAjuste.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Data de Ajuste";
            // 
            // txtBoxDataAjuste
            // 
            this.txtBoxDataAjuste.Location = new System.Drawing.Point(75, 43);
            this.txtBoxDataAjuste.Name = "txtBoxDataAjuste";
            this.txtBoxDataAjuste.ReadOnly = true;
            this.txtBoxDataAjuste.Size = new System.Drawing.Size(120, 20);
            this.txtBoxDataAjuste.TabIndex = 2;
            this.txtBoxDataAjuste.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "ID Ajuste";
            // 
            // txtBoxIDAjuste
            // 
            this.txtBoxIDAjuste.Location = new System.Drawing.Point(19, 43);
            this.txtBoxIDAjuste.Name = "txtBoxIDAjuste";
            this.txtBoxIDAjuste.ReadOnly = true;
            this.txtBoxIDAjuste.Size = new System.Drawing.Size(41, 20);
            this.txtBoxIDAjuste.TabIndex = 0;
            this.txtBoxIDAjuste.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblFutura);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.lblAtual);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.btnPesquisarComp);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtBoxQtdComp);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtBoxDescricaoComp);
            this.groupBox2.Controls.Add(this.txtBoxCodComp);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Location = new System.Drawing.Point(12, 134);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(210, 194);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dados do Componente";
            // 
            // lblFutura
            // 
            this.lblFutura.AutoSize = true;
            this.lblFutura.Location = new System.Drawing.Point(178, 163);
            this.lblFutura.Name = "lblFutura";
            this.lblFutura.Size = new System.Drawing.Size(13, 13);
            this.lblFutura.TabIndex = 17;
            this.lblFutura.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(106, 163);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Qtde. Futura:";
            // 
            // lblAtual
            // 
            this.lblAtual.AutoSize = true;
            this.lblAtual.Location = new System.Drawing.Point(170, 141);
            this.lblAtual.Name = "lblAtual";
            this.lblAtual.Size = new System.Drawing.Size(13, 13);
            this.lblAtual.TabIndex = 15;
            this.lblAtual.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(106, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Qtde. Atual:";
            // 
            // btnPesquisarComp
            // 
            this.btnPesquisarComp.BackgroundImage = global::ProjetoCompositor.Properties.Resources.Pesquisar;
            this.btnPesquisarComp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPesquisarComp.Location = new System.Drawing.Point(168, 16);
            this.btnPesquisarComp.Name = "btnPesquisarComp";
            this.btnPesquisarComp.Size = new System.Drawing.Size(36, 33);
            this.btnPesquisarComp.TabIndex = 3;
            this.btnPesquisarComp.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(113, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Qtde.:";
            // 
            // txtBoxQtdComp
            // 
            this.txtBoxQtdComp.Location = new System.Drawing.Point(116, 107);
            this.txtBoxQtdComp.Name = "txtBoxQtdComp";
            this.txtBoxQtdComp.Size = new System.Drawing.Size(68, 20);
            this.txtBoxQtdComp.TabIndex = 4;
            this.txtBoxQtdComp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBoxQtdComp_KeyDown);
            this.txtBoxQtdComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxQtdComp_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Cod. Comp.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Descrição Componente";
            // 
            // txtBoxDescricaoComp
            // 
            this.txtBoxDescricaoComp.Location = new System.Drawing.Point(13, 68);
            this.txtBoxDescricaoComp.Name = "txtBoxDescricaoComp";
            this.txtBoxDescricaoComp.Size = new System.Drawing.Size(176, 20);
            this.txtBoxDescricaoComp.TabIndex = 2;
            this.txtBoxDescricaoComp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBoxDescricaoComp_KeyDown);
            // 
            // txtBoxCodComp
            // 
            this.txtBoxCodComp.Location = new System.Drawing.Point(13, 31);
            this.txtBoxCodComp.Name = "txtBoxCodComp";
            this.txtBoxCodComp.Size = new System.Drawing.Size(47, 20);
            this.txtBoxCodComp.TabIndex = 1;
            this.txtBoxCodComp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBoxCodComp_KeyDown);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbSubtracao);
            this.groupBox3.Controls.Add(this.rbAdicao);
            this.groupBox3.Location = new System.Drawing.Point(6, 91);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(98, 74);
            this.groupBox3.TabIndex = 10;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tipo de Ajuste:";
            // 
            // rbSubtracao
            // 
            this.rbSubtracao.AutoSize = true;
            this.rbSubtracao.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSubtracao.ForeColor = System.Drawing.Color.Red;
            this.rbSubtracao.Location = new System.Drawing.Point(31, 44);
            this.rbSubtracao.Name = "rbSubtracao";
            this.rbSubtracao.Size = new System.Drawing.Size(32, 23);
            this.rbSubtracao.TabIndex = 6;
            this.rbSubtracao.TabStop = true;
            this.rbSubtracao.Text = "-";
            this.rbSubtracao.UseVisualStyleBackColor = true;
            // 
            // rbAdicao
            // 
            this.rbAdicao.AutoSize = true;
            this.rbAdicao.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAdicao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.rbAdicao.Location = new System.Drawing.Point(30, 21);
            this.rbAdicao.Name = "rbAdicao";
            this.rbAdicao.Size = new System.Drawing.Size(36, 23);
            this.rbAdicao.TabIndex = 5;
            this.rbAdicao.TabStop = true;
            this.rbAdicao.Text = "+";
            this.rbAdicao.UseVisualStyleBackColor = true;
            // 
            // btnAjustar
            // 
            this.btnAjustar.Location = new System.Drawing.Point(25, 334);
            this.btnAjustar.Name = "btnAjustar";
            this.btnAjustar.Size = new System.Drawing.Size(75, 23);
            this.btnAjustar.TabIndex = 7;
            this.btnAjustar.Text = "Ajustar";
            this.btnAjustar.UseVisualStyleBackColor = true;
            this.btnAjustar.Click += new System.EventHandler(this.btnAjustar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(132, 334);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // TelaSaida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(235, 391);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnAjustar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TelaSaida";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ajuste de Estoque";
            this.Load += new System.EventHandler(this.TelaSaida_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxIDAjuste;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxDataAjuste;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxAtorAjuste;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBoxDescricaoComp;
        private System.Windows.Forms.TextBox txtBoxCodComp;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtBoxQtdComp;
        private System.Windows.Forms.Button btnPesquisarComp;
        private System.Windows.Forms.Button btnAjustar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.RadioButton rbSubtracao;
        private System.Windows.Forms.RadioButton rbAdicao;
        private System.Windows.Forms.Label lblFutura;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblAtual;
        private System.Windows.Forms.Label label7;
    }
}