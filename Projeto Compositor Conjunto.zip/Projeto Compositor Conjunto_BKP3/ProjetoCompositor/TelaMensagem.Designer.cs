﻿namespace ProjetoCompositor
{
    partial class TelaMensagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pcbMensagem = new System.Windows.Forms.PictureBox();
            this.lblMensagem = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pcbMensagem)).BeginInit();
            this.SuspendLayout();
            // 
            // pcbMensagem
            // 
            this.pcbMensagem.BackgroundImage = global::ProjetoCompositor.Properties.Resources.Xis_Vermelho;
            this.pcbMensagem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pcbMensagem.Location = new System.Drawing.Point(12, 12);
            this.pcbMensagem.Name = "pcbMensagem";
            this.pcbMensagem.Size = new System.Drawing.Size(133, 112);
            this.pcbMensagem.TabIndex = 0;
            this.pcbMensagem.TabStop = false;
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Location = new System.Drawing.Point(61, 145);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(28, 13);
            this.lblMensagem.TabIndex = 1;
            this.lblMensagem.Text = "-------";
            this.lblMensagem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TelaMensagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(155, 173);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.pcbMensagem);
            this.Name = "TelaMensagem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ATENÇÃO";
            this.Load += new System.EventHandler(this.TelaMensagem_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TelaMensagem_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pcbMensagem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pcbMensagem;
        private System.Windows.Forms.Label lblMensagem;
    }
}