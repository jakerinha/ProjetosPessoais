﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace ProjetoCompositor
{
    class ClassConexao
    {

        public static string conexao = ProjetoCompositor.Properties.Settings.Default.strConexao;
        public static SqlConnection connection = new SqlConnection(conexao);

        public static void Aberto()
        {
            if(connection.State != System.Data.ConnectionState.Open)
            {
                connection.Open();
            }
        }

        public static void Fechar()
        {
            if(connection.State == System.Data.ConnectionState.Open)
            {

                
                connection.Close();
                
                
            }
        }


    }
}
