﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCompositor
{
    public partial class TelaMensagem : Form
    {
        public TelaMensagem()
        {
            InitializeComponent();
        }

        private void TelaMensagem_Load(object sender, EventArgs e)
        {
            if (ClassUtilidades._verificamensagem != 0)
            {
                pcbMensagem.BackgroundImage = ProjetoCompositor.Properties.Resources.Seta_verde;
                lblMensagem.Text = "SUCESSO!";

            }
            else
            {
                pcbMensagem.BackgroundImage = ProjetoCompositor.Properties.Resources.Xis_Vermelho;
                lblMensagem.Text = "FALHA!";
            }
        }

        private void TelaMensagem_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.Close();
            }
        }
    }
}
