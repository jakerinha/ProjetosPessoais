﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Data.SqlClient;


namespace ProjetoCompositor
{
    public partial class TelaLogin : Form
    {
        Thread troca;
        public TelaLogin()
        {
            InitializeComponent();
        }

        private void BtnEntrar_Click(object sender, EventArgs e)
        {
            try
            {
                string pesquisar = "SELECT top 1 usuario_func, senha_func, perfil_func from tb_funcionarios where usuario_func like @usuario_func and senha_func = @senha_func";

                SqlCommand search = new SqlCommand(pesquisar, ClassConexao.connection);
                ClassConexao.Aberto();

                search.Parameters.AddWithValue("@usuario_func", txtUsuario.Text);
                search.Parameters.AddWithValue("@senha_func", txtSenha.Text);

                SqlDataReader dataReader = search.ExecuteReader();

                if(dataReader.Read() != false)
                {
                    MessageBox.Show("AS CREDENCIAIS ESTÃO CORRETAS!", "SEJA BEM-VINDO!",MessageBoxButtons.OK,MessageBoxIcon.Information);

                    ClassUtilidades._usuario = txtUsuario.Text;
                    ClassUtilidades._perfil = dataReader.GetString(2);
                    
                    this.Close();
                    troca = new Thread(telaPrincipal);
                    troca.SetApartmentState(ApartmentState.STA);
                    troca.Start();
                }
                else
                {
                    MessageBox.Show("AS CREDENCIAIS ESTÃO INCORRETAS,\n FAVOR INSIRA NOVAMENTE!", "ATENÇÃO!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                ClassConexao.Fechar();

            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void telaPrincipal()
        {
            try
            {
                Application.Run(new TelaPrincipal());
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            try
            {
                this.Close();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }
    }
}
