﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCompositor
{
    public partial class TelaMovimentacao : Form
    {
        DateTime date = new DateTime();
        public TelaMovimentacao()
        {
            InitializeComponent();
        }

        private void EntradaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaEntrada entrada = new TelaEntrada();
            entrada.ShowDialog();
        }

        private void saídaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaSaida saida = new TelaSaida();
            saida.ShowDialog();
        }

        private void TelaMovimentacao_Load(object sender, EventArgs e)
        {
            date = DateTime.Now.Date;
            dtpInicial.Value = date;
            dtpFinal.Value = date;
            // TODO: esta linha de código carrega dados na tabela 'bDCompositorMovimentacao.tb_movimentacao'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_movimentacaoTableAdapter.Fill(this.bDCompositorMovimentacao.tb_movimentacao);
            int i;
            for (i = 0; i<=dgvFiltro.Rows.Count - 1; i++)
            {
                if(dgvFiltro.Rows[i].Cells[statusmovDGVtxtbox.Index].Value.ToString() == "E")
                {
                    dgvFiltro.Rows[i].Cells[statusmovDGVtxtbox.Index].Style.BackColor = Color.LightGreen;
                }
                else
                {
                    dgvFiltro.Rows[i].Cells[statusmovDGVtxtbox.Index].Style.BackColor = Color.LightSalmon;
                }
            }
        }

        private void estoqueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaProducao producao = new TelaProducao();

            producao.ShowDialog();
        }
    }
}
