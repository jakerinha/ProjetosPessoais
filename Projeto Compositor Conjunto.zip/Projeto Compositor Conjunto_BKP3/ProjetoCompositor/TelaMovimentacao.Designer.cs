﻿namespace ProjetoCompositor
{
    partial class TelaMovimentacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnPesquisarFiltro = new System.Windows.Forms.Button();
            this.dtpFinal = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpInicial = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.cbMovimento = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.movimentaçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.entradaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saídaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvFiltro = new System.Windows.Forms.DataGridView();
            this.tbmovimentacaoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bDCompositorMovimentacao = new ProjetoCompositor.BDCompositorMovimentacao();
            this.tb_movimentacaoTableAdapter = new ProjetoCompositor.BDCompositorMovimentacaoTableAdapters.tb_movimentacaoTableAdapter();
            this.estoqueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusmovDGVtxtbox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idmovDGVtxtbox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descricaomovDGVtxtbox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataentradaDGVtxtbox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datasaidaDGVtxtbox = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFiltro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbmovimentacaoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDCompositorMovimentacao)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnPesquisarFiltro);
            this.groupBox1.Controls.Add(this.dtpFinal);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dtpInicial);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cbMovimento);
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(529, 90);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Filtro";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(319, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Data Final";
            // 
            // btnPesquisarFiltro
            // 
            this.btnPesquisarFiltro.Location = new System.Drawing.Point(15, 59);
            this.btnPesquisarFiltro.Name = "btnPesquisarFiltro";
            this.btnPesquisarFiltro.Size = new System.Drawing.Size(69, 26);
            this.btnPesquisarFiltro.TabIndex = 10;
            this.btnPesquisarFiltro.Text = "Pesquisar";
            this.btnPesquisarFiltro.UseVisualStyleBackColor = true;
            // 
            // dtpFinal
            // 
            this.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFinal.Location = new System.Drawing.Point(322, 32);
            this.dtpFinal.Name = "dtpFinal";
            this.dtpFinal.Size = new System.Drawing.Size(189, 20);
            this.dtpFinal.TabIndex = 4;
            this.dtpFinal.Value = new System.DateTime(2019, 12, 17, 0, 0, 0, 0);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(144, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Data Inicial";
            // 
            // dtpInicial
            // 
            this.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInicial.Location = new System.Drawing.Point(147, 32);
            this.dtpInicial.Name = "dtpInicial";
            this.dtpInicial.Size = new System.Drawing.Size(165, 20);
            this.dtpInicial.TabIndex = 2;
            this.dtpInicial.Value = new System.DateTime(2019, 12, 17, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Movimento";
            // 
            // cbMovimento
            // 
            this.cbMovimento.FormattingEnabled = true;
            this.cbMovimento.Items.AddRange(new object[] {
            "ENTRADA",
            "SAIDA"});
            this.cbMovimento.Location = new System.Drawing.Point(15, 32);
            this.cbMovimento.Name = "cbMovimento";
            this.cbMovimento.Size = new System.Drawing.Size(121, 21);
            this.cbMovimento.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.movimentaçõesToolStripMenuItem,
            this.estoqueToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(553, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // movimentaçõesToolStripMenuItem
            // 
            this.movimentaçõesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.entradaToolStripMenuItem,
            this.saídaToolStripMenuItem});
            this.movimentaçõesToolStripMenuItem.Name = "movimentaçõesToolStripMenuItem";
            this.movimentaçõesToolStripMenuItem.Size = new System.Drawing.Size(104, 20);
            this.movimentaçõesToolStripMenuItem.Text = "Movimentações";
            // 
            // entradaToolStripMenuItem
            // 
            this.entradaToolStripMenuItem.Name = "entradaToolStripMenuItem";
            this.entradaToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.entradaToolStripMenuItem.Text = "Entrada";
            this.entradaToolStripMenuItem.Click += new System.EventHandler(this.EntradaToolStripMenuItem_Click);
            // 
            // saídaToolStripMenuItem
            // 
            this.saídaToolStripMenuItem.Name = "saídaToolStripMenuItem";
            this.saídaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saídaToolStripMenuItem.Text = "Saída";
            this.saídaToolStripMenuItem.Click += new System.EventHandler(this.saídaToolStripMenuItem_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.Tag = "";
            this.toolTip1.ToolTipTitle = "Pesquisar (Componente/Conjunto)";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvFiltro);
            this.groupBox2.Location = new System.Drawing.Point(30, 125);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(495, 209);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Movimento";
            // 
            // dgvFiltro
            // 
            this.dgvFiltro.AllowUserToAddRows = false;
            this.dgvFiltro.AllowUserToDeleteRows = false;
            this.dgvFiltro.AutoGenerateColumns = false;
            this.dgvFiltro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFiltro.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.statusmovDGVtxtbox,
            this.idmovDGVtxtbox,
            this.descricaomovDGVtxtbox,
            this.dataentradaDGVtxtbox,
            this.datasaidaDGVtxtbox});
            this.dgvFiltro.DataSource = this.tbmovimentacaoBindingSource;
            this.dgvFiltro.Location = new System.Drawing.Point(9, 17);
            this.dgvFiltro.Name = "dgvFiltro";
            this.dgvFiltro.ReadOnly = true;
            this.dgvFiltro.Size = new System.Drawing.Size(475, 184);
            this.dgvFiltro.TabIndex = 0;
            // 
            // tbmovimentacaoBindingSource
            // 
            this.tbmovimentacaoBindingSource.DataMember = "tb_movimentacao";
            this.tbmovimentacaoBindingSource.DataSource = this.bDCompositorMovimentacao;
            // 
            // bDCompositorMovimentacao
            // 
            this.bDCompositorMovimentacao.DataSetName = "BDCompositorMovimentacao";
            this.bDCompositorMovimentacao.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tb_movimentacaoTableAdapter
            // 
            this.tb_movimentacaoTableAdapter.ClearBeforeFill = true;
            // 
            // estoqueToolStripMenuItem
            // 
            this.estoqueToolStripMenuItem.Name = "estoqueToolStripMenuItem";
            this.estoqueToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.estoqueToolStripMenuItem.Text = "Produção";
            this.estoqueToolStripMenuItem.Click += new System.EventHandler(this.estoqueToolStripMenuItem_Click);
            // 
            // statusmovDGVtxtbox
            // 
            this.statusmovDGVtxtbox.DataPropertyName = "status_mov";
            this.statusmovDGVtxtbox.HeaderText = "Status(E/S)";
            this.statusmovDGVtxtbox.Name = "statusmovDGVtxtbox";
            this.statusmovDGVtxtbox.ReadOnly = true;
            this.statusmovDGVtxtbox.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.statusmovDGVtxtbox.Width = 65;
            // 
            // idmovDGVtxtbox
            // 
            this.idmovDGVtxtbox.DataPropertyName = "id_mov";
            this.idmovDGVtxtbox.HeaderText = "ID Mov.";
            this.idmovDGVtxtbox.Name = "idmovDGVtxtbox";
            this.idmovDGVtxtbox.ReadOnly = true;
            this.idmovDGVtxtbox.Width = 65;
            // 
            // descricaomovDGVtxtbox
            // 
            this.descricaomovDGVtxtbox.DataPropertyName = "descricao_mov";
            this.descricaomovDGVtxtbox.HeaderText = "Descrição Mov.";
            this.descricaomovDGVtxtbox.Name = "descricaomovDGVtxtbox";
            this.descricaomovDGVtxtbox.ReadOnly = true;
            // 
            // dataentradaDGVtxtbox
            // 
            this.dataentradaDGVtxtbox.DataPropertyName = "data_entrada";
            this.dataentradaDGVtxtbox.HeaderText = "Data Entrada";
            this.dataentradaDGVtxtbox.Name = "dataentradaDGVtxtbox";
            this.dataentradaDGVtxtbox.ReadOnly = true;
            // 
            // datasaidaDGVtxtbox
            // 
            this.datasaidaDGVtxtbox.DataPropertyName = "data_saida";
            this.datasaidaDGVtxtbox.HeaderText = "Data Saída";
            this.datasaidaDGVtxtbox.Name = "datasaidaDGVtxtbox";
            this.datasaidaDGVtxtbox.ReadOnly = true;
            // 
            // TelaMovimentacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 345);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "TelaMovimentacao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Movimentação";
            this.Load += new System.EventHandler(this.TelaMovimentacao_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFiltro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbmovimentacaoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDCompositorMovimentacao)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem movimentaçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem entradaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saídaToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpFinal;
        private System.Windows.Forms.DateTimePicker dtpInicial;
        private System.Windows.Forms.ComboBox cbMovimento;
        private System.Windows.Forms.Button btnPesquisarFiltro;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvFiltro;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private BDCompositorMovimentacao bDCompositorMovimentacao;
        private System.Windows.Forms.BindingSource tbmovimentacaoBindingSource;
        private BDCompositorMovimentacaoTableAdapters.tb_movimentacaoTableAdapter tb_movimentacaoTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem estoqueToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusmovDGVtxtbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn idmovDGVtxtbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn descricaomovDGVtxtbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataentradaDGVtxtbox;
        private System.Windows.Forms.DataGridViewTextBoxColumn datasaidaDGVtxtbox;
    }
}