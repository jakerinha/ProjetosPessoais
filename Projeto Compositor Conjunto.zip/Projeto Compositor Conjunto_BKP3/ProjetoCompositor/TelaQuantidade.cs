﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCompositor
{
    public partial class TelaQuantidade : Form
    {
        public TelaQuantidade()
        {
            InitializeComponent();
            txtQtdComp.Focus();
            txtQtdComp.Clear();

        }
        private void TxtQtdComp_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                
                if (string.IsNullOrWhiteSpace(txtQtdComp.Text))
                {
                    MessageBox.Show("Favor inserir valor válido!", "ATENÇÃO");
                }
                else
                {
                    ClassUtilidades._qtdeComp = Convert.ToInt32(txtQtdComp.Text);
                    this.Close();
                }


                
            }
        }
    }
}
