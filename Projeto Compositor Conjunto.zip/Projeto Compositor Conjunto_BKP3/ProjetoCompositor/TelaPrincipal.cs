﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCompositor
{
    public partial class TelaPrincipal : Form
    {
        DateTime hora;
        public TelaPrincipal()
        {
            InitializeComponent();
            lblUsuario.Text = ClassUtilidades._usuario;
            //Haverá uma finalidade o perfil do usuário, por enquanto 
            //ficará quieto!!!!

        }

        private void TelaPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            Saindo(e);
        }

        private void Temporizador_Tick(object sender, EventArgs e)
        {
            hora = DateTime.Now;
            lblHora.Text = hora.ToString();
        }

        private void FuncionáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaCadastroFuncionario cadastroFuncionario = new TelaCadastroFuncionario();
            cadastroFuncionario.ShowDialog();
        }

        private void ComponentesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaCadastroComponente cadastroComponente = new TelaCadastroComponente();
            cadastroComponente.ShowDialog();
        }

        private void SobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaSobre sobre = new TelaSobre();
            sobre.ShowDialog();
        }

        private void ModelosToolStripMenuItem_Click(object sender, EventArgs e)
        {

            TelaModelo modelo = new TelaModelo();
            modelo.ShowDialog();

        }

        private void ConjuntosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaCadastroConjunto cadastroConjunto = new TelaCadastroConjunto();
            cadastroConjunto.ShowDialog();
        }

        private void MovimentaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TelaMovimentacao movimentacao = new TelaMovimentacao();
            movimentacao.ShowDialog();
        }

        private void Saindo(FormClosingEventArgs e)
        {
            if (MessageBox.Show("DESEJA SAIR?", "ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }
    }
}
