﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjetoCompositor
{
    public partial class TelaProducao : Form
    {
        //Recebe o valor atual do componente dentro do conjunto
        int qtd_anterior;
        //Recebe o ID do Conjunto desejado
        int id_conj;
        //Recebe o ID do Componente desejado
        int id_comp = 0;

        DataSet ds = new DataSet();
        TelaPesquisaConjunto pesquisa = new TelaPesquisaConjunto();


        public TelaProducao()
        {
            InitializeComponent();

        }

        private void TelaSaida_Load(object sender, EventArgs e)
        {

            txtDataSaida.Text = DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
        }
        //Código utilizado para buscar o CONJUNTO através de seu ID
        private void BuscaConjuntoID()
        {
            try
            {

                if (String.IsNullOrEmpty(txtCodConjunto.Text) == true)
                {
                    MessageBox.Show("O campo do ID do conjunto está vázio!", "ATENÇÃO");
                }
                else
                {
                    ClassConexao.Aberto();

                    string seleciona_p_id = "SELECT top 1 id_conj,nome_conj FROM tb_conjuntos WHERE cod_conj like @cod_conj";

                    SqlCommand select_id = new SqlCommand(seleciona_p_id, ClassConexao.connection);

                    select_id.Parameters.AddWithValue("@cod_conj", txtCodConjunto.Text);

                    ClassUtilidades.DataReader = select_id.ExecuteReader();

                    if (ClassUtilidades.DataReader.Read() != false)
                    {

                        id_conj = ClassUtilidades.DataReader.GetInt32(0);
                        //MessageBox.Show(id_conj.ToString());
                        txtDescricaoConjunto.Text = ClassUtilidades.DataReader.GetString(1);

                        ClassUtilidades.DataReader.Close();
                        //dataReader.Dispose();
                    }
                    else
                    {

                        MessageBox.Show("Leitura do valor não efetuada!");
                    }
                    BuscaComponentesID();
                    Seleciona_Quantia_Atual();
                    ClassConexao.Fechar();
                }

            }
            catch (Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void txtIDConjunto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BuscaConjuntoID();
                //BuscaComponentesID();
                //Seleciona_Quantia_Atual();
                //ComparacaoQuantidades();
                //Bloqueia as células relacionadas ao Código e Nome do Conjunto
                txtCodConjunto.Enabled = false;
                txtDescricaoConjunto.Enabled = false;

                //Foca o cursor na caixa de texto para quantidade a ser produzida.

                txtQtdeConjunto.Focus();

            }
        }
        //Código utilizado para buscar COMPONENTES através de seu ID.
        private void BuscaComponentesID()
        {
            try
            {

                ClassConexao.Aberto();

                string seleciona_p_id = "SELECT id_comp, nome_comp, qtde_comp FROM tb_conjuntos_componentes WHERE id_conj = '" + id_conj + "'";

                SqlCommand select_id = new SqlCommand(seleciona_p_id, ClassConexao.connection);
                //Convertendo o valor id_conj para int, pois seu tipo é string.
                //select_id.Parameters.AddWithValue("@id_conj", id_conj);

                //Prosseguir com o código para inserção dos componentes pertencentes a determinado conjunto!

                //Próximo passo -> Explodir no DataGridView os componentes

                //Preenche o datagridview com os dados armazenados na tabela tb_conjuntos_componentes
                SqlDataAdapter dataAdapter = new SqlDataAdapter(select_id);

                dataAdapter.Fill(ds);

                dgvComponentes.DataSource = ds;
                dgvComponentes.DataMember = ds.Tables[0].TableName;

                ClassConexao.Fechar();

            }
            catch (Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }
        //Código que calcula a quantidade desejada do conjunto, que posteriormente serão utilizados na produção.
        private void QtdeProducao()
        {
            try
            {
                if (String.IsNullOrEmpty(txtQtdeConjunto.Text))
                {
                    MessageBox.Show("Quantidade não pode ser vázio!", "ATENÇÃO");
                }
                else
                {
                    //Essa variável é diferente da outra qtd_. Pois essa recebe o valor do textbox quantidade do conjunto.
                    int qtde = Convert.ToInt32(txtQtdeConjunto.Text);
                    int i;

                    for (i = 0; i < dgvComponentes.Rows.Count; i++)
                    {
                        
                        qtd_anterior = Convert.ToInt32(dgvComponentes.Rows[i].Cells[qtdecompDGVtxtbox.Index].Value.ToString());
                        qtd_anterior *= qtde;
                        dgvComponentes.Rows[i].Cells[qtdecompDGVtxtbox.Index].Value = qtd_anterior;

                    }

                }
            }
            catch (Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        private void txtQtdeConjunto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                QtdeProducao();
                ComparacaoQuantidades();
                txtQtdeConjunto.Clear();
            }
        }

        private void txtDescricaoConjunto_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                BuscaConjuntoDescricao();
                BuscaConjuntoID();

            }
        }
        //Código utilizado para buscar um conjunto através de seu nome/descrição
        private void BuscaConjuntoDescricao()
        {
            try
            {
                if (String.IsNullOrEmpty(txtDescricaoConjunto.Text) != false)
                {
                    MessageBox.Show("Descrição não pode ser vazia!", "ATENÇÃO");
                    ClassUtilidades.DataReader.Close();
                }
                else
                {
                    ClassConexao.Aberto();

                    string seleciona_p_nome = "SELECT id_conj FROM tb_conjuntos WHERE nome_conj like '%" + txtDescricaoConjunto.Text + "%'";

                    SqlCommand select_name = new SqlCommand(seleciona_p_nome, ClassConexao.connection);

                    ClassUtilidades.DataReader = select_name.ExecuteReader();

                    if (ClassUtilidades.DataReader.Read() != false)
                    {
                        ClassUtilidades.DataReader.Close();
                        ClassUtilidades._descricao_conjunto = txtDescricaoConjunto.Text;

                        pesquisa.ShowDialog();

                        id_conj = ClassUtilidades._id_conjunto;
                        txtDescricaoConjunto.Text = ClassUtilidades._veredito_descricao;
                        txtCodConjunto.Text = ClassUtilidades._cod_conjunto;

                        //BuscaComponentesID();
                        //Seleciona_Quantia_Atual();
                       //ComparacaoQuantidades();

                        txtCodConjunto.Enabled = false;
                        txtDescricaoConjunto.Enabled = false;

                        txtQtdeConjunto.Focus();

                    }
                    else
                    {
                        MessageBox.Show("Leitura do valor informado sem sucesso!", "ATENÇÃO");
                        ClassUtilidades.DataReader.Close();
                    }

                    //ClassUtilidades.DataReader.Close();
                    //reader.Dispose();

                    ClassConexao.Fechar();
                }



            }
            catch (Exception Msg1)
            {
                MessageBox.Show(Msg1.Message);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            Limpar();
        }

        private void Limpar()
        {
            txtCodConjunto.Clear();
            txtDescricaoConjunto.Clear();
            txtQtdeConjunto.Clear();
            ds.Clear();

            txtCodConjunto.Enabled = true;
            txtDescricaoConjunto.Enabled = true;

            //MessageBox.Show("Cancelando Produção......");
            this.Close();
        }

        private void btnGerarSaida_Click(object sender, EventArgs e)
        {
            CriarSaida();
        }

        //Código utilizado para gerar a produção de determinado conjunto
        private void CriarSaida()
        {
            try
            {
                ClassConexao.Aberto();
                int i;
                string atualiza_estoque = "UPDATE tb_componentes SET qtd_comp = @qtd_comp WHERE id_comp = @id_comp";

                SqlCommand update = new SqlCommand(atualiza_estoque, ClassConexao.connection);

                for (i = 0; i <= dgvComponentes.Rows.Count - 1; i++)
                {
                    id_comp = Convert.ToInt32(dgvComponentes.Rows[i].Cells[idcompDGVtxtbox.Index].Value);

                    //Seleciona_Quantidade(id_comp);

                    update.Parameters.AddWithValue("@id_comp", id_comp);
                    //qtd_ -= Convert.ToInt32(dgvComponentes.Rows[i].Cells[qtdecompDGVtxtbox.Index].Value.ToString());
                    update.Parameters.AddWithValue("@qtd_comp", Convert.ToInt32(dgvComponentes.Rows[i].Cells[qtde_atual_comp.Index].Value) - Convert.ToInt32(dgvComponentes.Rows[i].Cells[qtdecompDGVtxtbox.Index].Value));

                    update.ExecuteNonQuery();
                    update.Parameters.Clear();
                }
                MessageBox.Show("Gerando Saída.....");
                ClassConexao.Fechar();
                this.Close();
            }
            catch (Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }

        //Código para apresentar o quantidade de componentes no estoque
        private void Seleciona_Quantia_Atual()
        {
            try
            {
                ClassConexao.Aberto();
                int i;
                string seleciona_quantia_atual = "SELECT qtd_comp FROM tb_componentes WHERE id_comp = @id_comp";

                SqlCommand select_quantia_atual = new SqlCommand(seleciona_quantia_atual, ClassConexao.connection);


                for (i = 0; i<=dgvComponentes.Rows.Count - 1; i++)
                {
                    select_quantia_atual.Parameters.AddWithValue("@id_comp", Convert.ToInt32(dgvComponentes.Rows[i].Cells[idcompDGVtxtbox.Index].Value));

                    ClassUtilidades.DataReader = select_quantia_atual.ExecuteReader();

                    if (ClassUtilidades.DataReader.Read() != false)
                    {
                        //Atenção aos tipos de dados que está sendo usado no banco de dados..... Pode haver dificuldades posteriormente!
                        dgvComponentes.Rows[i].Cells[qtde_atual_comp.Index].Value = ClassUtilidades.DataReader.GetInt32(0);
                        ClassUtilidades.DataReader.Close();
                        select_quantia_atual.Parameters.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Leitura do valor informado sem sucesso!", "ATENÇÃO");
                        ClassUtilidades.DataReader.Close();
                        select_quantia_atual.Parameters.Clear();
                    }

                }

                ClassConexao.Fechar();
            }
            catch(Exception msg1)
            {
                MessageBox.Show(msg1.Message);
            }
        }
        
        //Código utilizado para comparar a quantidade de componentes no estoque e a quantidade requisitada!
        private void ComparacaoQuantidades()
        {
            int i;
            int total_irregular = 0;
            for (i = 0; i<=dgvComponentes.Rows.Count - 1; i++)
            {
                int valor_a = Convert.ToInt32(dgvComponentes.Rows[i].Cells[qtde_atual_comp.Index].Value);
                int valor_b = Convert.ToInt32(dgvComponentes.Rows[i].Cells[qtdecompDGVtxtbox.Index].Value);
                if (valor_a>=valor_b)
                {
                    dgvComponentes.Rows[i].Cells[qtde_atual_comp.Index].Style.ForeColor = Color.Black;
                }
                else
                {
                    dgvComponentes.Rows[i].Cells[qtde_atual_comp.Index].Style.ForeColor = Color.Red;
                    total_irregular++;
                    btnProduzir.Enabled = false;
                    
                }
            }
            if (total_irregular > 0)
            {
                MessageBox.Show(total_irregular + " componente(s) não tem quantidade no estoque!");
            }
           
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //Chamando telaPesquisaConjunto
            TelaPesquisaConjunto pesquisaConjunto = new TelaPesquisaConjunto();
            pesquisaConjunto.ShowDialog();

            txtCodConjunto.Text = ClassUtilidades._cod_conjunto;
            txtDescricaoConjunto.Text = ClassUtilidades._veredito_descricao;
            txtCodConjunto.Enabled = false;
            txtDescricaoConjunto.Enabled = false;

            BuscaConjuntoID();
            
        }
    }
}
