﻿namespace ProjetoCompositor
{
    partial class TelaEntrada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpEmissao = new System.Windows.Forms.DateTimePicker();
            this.txtDataAtual = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNumNota = new System.Windows.Forms.TextBox();
            this.txtIDmovimento = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtQtdeEntrada = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnBuscaComp = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCODcomp = new System.Windows.Forms.TextBox();
            this.txtDescricaoComp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnGerarEntrada = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.dtpEmissao);
            this.groupBox1.Controls.Add(this.txtDataAtual);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNumNota);
            this.groupBox1.Controls.Add(this.txtIDmovimento);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(330, 115);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados da Entrada";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Data Emissão Nota";
            // 
            // dtpEmissao
            // 
            this.dtpEmissao.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEmissao.Location = new System.Drawing.Point(115, 81);
            this.dtpEmissao.Name = "dtpEmissao";
            this.dtpEmissao.Size = new System.Drawing.Size(96, 20);
            this.dtpEmissao.TabIndex = 2;
            // 
            // txtDataAtual
            // 
            this.txtDataAtual.Location = new System.Drawing.Point(9, 81);
            this.txtDataAtual.Name = "txtDataAtual";
            this.txtDataAtual.ReadOnly = true;
            this.txtDataAtual.Size = new System.Drawing.Size(100, 20);
            this.txtDataAtual.TabIndex = 2;
            this.txtDataAtual.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Data Entrada";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nº Nota Fiscal";
            // 
            // txtNumNota
            // 
            this.txtNumNota.Location = new System.Drawing.Point(47, 42);
            this.txtNumNota.Name = "txtNumNota";
            this.txtNumNota.Size = new System.Drawing.Size(277, 20);
            this.txtNumNota.TabIndex = 1;
            this.txtNumNota.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumNota_KeyPress);
            // 
            // txtIDmovimento
            // 
            this.txtIDmovimento.Location = new System.Drawing.Point(9, 42);
            this.txtIDmovimento.Name = "txtIDmovimento";
            this.txtIDmovimento.ReadOnly = true;
            this.txtIDmovimento.Size = new System.Drawing.Size(32, 20);
            this.txtIDmovimento.TabIndex = 1;
            this.txtIDmovimento.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtQtdeEntrada);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.btnBuscaComp);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.txtCODcomp);
            this.groupBox2.Controls.Add(this.txtDescricaoComp);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(12, 133);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(330, 102);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Atualizando Componente";
            // 
            // txtQtdeEntrada
            // 
            this.txtQtdeEntrada.Location = new System.Drawing.Point(6, 71);
            this.txtQtdeEntrada.Name = "txtQtdeEntrada";
            this.txtQtdeEntrada.Size = new System.Drawing.Size(57, 20);
            this.txtQtdeEntrada.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Qtde. Entrada";
            // 
            // btnBuscaComp
            // 
            this.btnBuscaComp.BackgroundImage = global::ProjetoCompositor.Properties.Resources.Pesquisar;
            this.btnBuscaComp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBuscaComp.Location = new System.Drawing.Point(299, 29);
            this.btnBuscaComp.Name = "btnBuscaComp";
            this.btnBuscaComp.Size = new System.Drawing.Size(25, 23);
            this.btnBuscaComp.TabIndex = 6;
            this.btnBuscaComp.UseVisualStyleBackColor = true;
            this.btnBuscaComp.Click += new System.EventHandler(this.btnBuscaComp_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Cód. Comp.";
            // 
            // txtCODcomp
            // 
            this.txtCODcomp.Location = new System.Drawing.Point(6, 32);
            this.txtCODcomp.Name = "txtCODcomp";
            this.txtCODcomp.Size = new System.Drawing.Size(57, 20);
            this.txtCODcomp.TabIndex = 3;
            this.txtCODcomp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtIDcomp_KeyDown);
            // 
            // txtDescricaoComp
            // 
            this.txtDescricaoComp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtDescricaoComp.Location = new System.Drawing.Point(71, 32);
            this.txtDescricaoComp.Name = "txtDescricaoComp";
            this.txtDescricaoComp.Size = new System.Drawing.Size(222, 20);
            this.txtDescricaoComp.TabIndex = 4;
            this.txtDescricaoComp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDescricaoComp_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(68, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Descrição Componente";
            // 
            // btnGerarEntrada
            // 
            this.btnGerarEntrada.Location = new System.Drawing.Point(18, 241);
            this.btnGerarEntrada.Name = "btnGerarEntrada";
            this.btnGerarEntrada.Size = new System.Drawing.Size(75, 39);
            this.btnGerarEntrada.TabIndex = 7;
            this.btnGerarEntrada.Text = "Gerar &Entrada";
            this.btnGerarEntrada.UseVisualStyleBackColor = true;
            this.btnGerarEntrada.Click += new System.EventHandler(this.btnGerarEntrada_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(99, 241);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 39);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // TelaEntrada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 288);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnGerarEntrada);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "TelaEntrada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Entrada";
            this.Load += new System.EventHandler(this.TelaEntrada_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpEmissao;
        private System.Windows.Forms.TextBox txtDataAtual;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNumNota;
        private System.Windows.Forms.TextBox txtIDmovimento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnBuscaComp;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCODcomp;
        private System.Windows.Forms.TextBox txtDescricaoComp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnGerarEntrada;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.TextBox txtQtdeEntrada;
        private System.Windows.Forms.Label label7;
    }
}